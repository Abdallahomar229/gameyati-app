package com.gameyati.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.print.SirPdfWriter;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * «جمعيتي» — غلاف أندرويد بسيط:
 * WebView بيعرض التطبيق من ملفاته (من غير إنترنت) على عنوان https داخلي،
 * وجسر للجافاسكريبت (GameyatiNative): مشاركة صور/ملفات/نصوص، فتح واتساب والاتصال، التنبيهات،
 * PDF، اختيار ملف النسخة الاحتياطية، «بلس»، الإعلانات، والاهتزاز.
 */
public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + HOST + "/index.html";
    static final int PAPER = 0xFFF6F4FB;
    static final int REQ_FILE = 41;
    static final int REQ_NOTIF = 42;

    WebView web;
    BillingBridge billing;
    AdsBridge ads;
    ValueCallback<Uri[]> fileCallback;
    boolean pdfBusy;
    String notifCb;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(PAPER);
        web = new WebView(this);
        web.setBackgroundColor(PAPER);
        root.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 30) {
            Api30.edgeToEdge(w, root);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setWebViewClient(new LocalClient());
        web.setWebChromeClient(new Chrome());
        web.addJavascriptInterface(new Bridge(), "GameyatiNative");

        billing = new BillingBridge(this);
        ads = new AdsBridge(this);
        if (Build.VERSION.SDK_INT >= 33) {
            Api33.registerBack(this);
        }

        if (state != null) {
            web.restoreState(state);
        }
        if (web.getUrl() == null) {
            web.loadUrl(START_URL);
        }
        cleanShareDir();
    }

    // ───────── الرجوع ─────────
    void handleBack() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            finish();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        handleBack();
    }

    /** ينفّذ جافاسكريبت في التطبيق (من أي thread) */
    void js(final String code) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (web != null) web.evaluateJavascript(code, null);
            }
        });
    }

    void setEntitled(boolean on) {
        js("window.__gamEntitlement&&window.__gamEntitlement(" + (on ? "true" : "false") + ")");
    }

    void adDone(boolean shown) {
        js("window.__gamAdDone&&window.__gamAdDone(" + (shown ? "true" : "false") + ")");
    }

    /** رد عام على أي طلب من الجافاسكريبت: window.__gamReply(id, json) */
    void reply(String cb, JSONObject o) {
        if (cb == null || cb.isEmpty()) return;
        js("window.__gamReply&&window.__gamReply(" + JSONObject.quote(cb) + "," + JSONObject.quote(o.toString()) + ")");
    }

    void reply(String cb, boolean ok, String reason) {
        try {
            JSONObject o = new JSONObject();
            o.put("ok", ok);
            if (reason != null) o.put("reason", reason);
            reply(cb, o);
        } catch (Exception ignored) {
        }
    }

    void pdfReply(String cb, boolean ok, String reason) {
        reply(cb, ok, reason);
    }

    // ───────── PDF ─────────
    static String safeName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]+", " ").trim();
        if (n.isEmpty()) n = "Gameyati";
        if (n.length() > 80) n = n.substring(0, 80);
        return n;
    }

    PrintAttributes a4() {
        return new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 600, 600))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build();
    }

    /** نافذة الطباعة بتاعة النظام (فيها «حفظ بصيغة PDF») */
    void printDialog(String name, String cb) {
        try {
            PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            PrintDocumentAdapter adapter = web.createPrintDocumentAdapter(name);
            pm.print(name, adapter, a4());
            pdfReply(cb, true, "dialog");
        } catch (Throwable t) {
            pdfReply(cb, false, "print");
        }
    }

    /** يعمل ملف PDF ويفتح المشاركة (واتساب، إيميل، Drive…) — ولو فشل يرجع لنافذة الطباعة */
    void sharePdf(final String name, final String cb) {
        if (pdfBusy) {
            pdfReply(cb, false, "busy");
            return;
        }
        pdfBusy = true;
        final File out = new File(new File(getCacheDir(), ShareProvider.DIR), name + ".pdf");
        PrintDocumentAdapter adapter;
        try {
            adapter = web.createPrintDocumentAdapter(name);
        } catch (Throwable t) {
            pdfBusy = false;
            printDialog(name, cb);
            return;
        }
        try {
            SirPdfWriter.write(adapter, a4(), out, new SirPdfWriter.Done() {
                @Override
                public void ok(File file) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            pdfBusy = false;
                            openShare(file, name, cb);
                        }
                    });
                }

                @Override
                public void fail(String why) {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            pdfBusy = false;
                            printDialog(name, cb);
                        }
                    });
                }
            });
        } catch (Throwable t) {
            pdfBusy = false;
            printDialog(name, cb);
        }
    }

    void openShare(File file, String name, String cb) {
        try {
            Uri uri = ShareProvider.uriFor(file);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("application/pdf");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TITLE, name + ".pdf");
            send.setClipData(ClipData.newRawUri(name, uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, "مشاركة التقرير"));
            pdfReply(cb, true, null);
        } catch (Throwable t) {
            printDialog(name, cb);
        }
    }

    void cleanShareDir() {
        try {
            File dir = new File(getCacheDir(), ShareProvider.DIR);
            File[] list = dir.listFiles();
            if (list == null) return;
            long old = System.currentTimeMillis() - 24L * 60 * 60 * 1000;
            for (File f : list) {
                if (f.lastModified() < old) f.delete();
            }
        } catch (Throwable ignored) {
        }
    }

    // ───────── مشاركة صورة/ملف/نص ─────────
    void shareFile(String b64, String mime, String name, String title, String cb) {
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            File dir = new File(getCacheDir(), ShareProvider.DIR);
            if (!dir.isDirectory()) dir.mkdirs();
            File out = new File(dir, safeName(name));
            java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
            try {
                fo.write(data);
            } finally {
                fo.close();
            }
            Uri uri = ShareProvider.uriFor(out);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime == null || mime.isEmpty() ? ShareProvider.mimeOf(out.getName()) : mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_TITLE, out.getName());
            send.setClipData(ClipData.newRawUri(out.getName(), uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(send, title == null || title.isEmpty() ? "مشاركة" : title));
            reply(cb, true, null);
        } catch (Throwable t) {
            reply(cb, false, "share");
        }
    }

    void shareText(String text, String title, String cb) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(send, title == null || title.isEmpty() ? "مشاركة" : title));
            reply(cb, true, null);
        } catch (Throwable t) {
            reply(cb, false, "share");
        }
    }

    void openUrl(String url) {
        try {
            Uri u = Uri.parse(url);
            Intent i = new Intent("tel".equals(u.getScheme()) ? Intent.ACTION_DIAL : Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    // ───────── إذن التنبيهات (أندرويد 13+) ─────────
    void askNotifications(String cb) {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notifCb = cb;
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
            return;
        }
        notifReply(cb);
    }

    void notifReply(String cb) {
        boolean on = true;
        try {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) on = nm.areNotificationsEnabled();
        } catch (Throwable ignored) {
        }
        try {
            JSONObject o = new JSONObject();
            o.put("ok", true);
            o.put("granted", on);
            reply(cb, o);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == REQ_NOTIF) {
            String cb = notifCb;
            notifCb = null;
            notifReply(cb);
        }
    }

    final class Bridge {
        @JavascriptInterface
        public String platform() {
            return "android";
        }

        /** مشاركة ملف (صورة الجدول/النسخة الاحتياطية) — b64 = محتوى الملف */
        @JavascriptInterface
        public void shareFile(final String b64, final String mime, final String name, final String title, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.shareFile(b64, mime, name, title, cb);
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String text, final String title, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.shareText(text, title, cb);
                }
            });
        }

        /** واتساب / اتصال / إيميل / متصفح */
        @JavascriptInterface
        public void open(final String url) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    openUrl(url);
                }
            });
        }

        /** التنبيهات: action = set (json = [{id, at, title, body}]) */
        @JavascriptInterface
        public void notify(final String action, final String json) {
            if ("set".equals(action)) ReminderReceiver.setAll(getApplicationContext(), json);
        }

        @JavascriptInterface
        public void notifyPermission(final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    askNotifications(cb);
                }
            });
        }

        /** action = share | print */
        @JavascriptInterface
        public void pdf(final String action, final String name, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (web == null) return;
                    String n = safeName(name);
                    if ("print".equals(action)) printDialog(n, cb);
                    else sharePdf(n, cb);
                }
            });
        }

        /** action = preload | interstitial */
        @JavascriptInterface
        public void ads(final String action) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (ads == null) return;
                    if ("interstitial".equals(action)) ads.show();
                    else ads.start();
                }
            });
        }

        @JavascriptInterface
        @SuppressWarnings("deprecation")
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                int d = Math.max(1, Math.min(ms, 300));
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(d, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(d);
                }
            } catch (Exception ignored) {
            }
        }

        /** «بلس»: action = offerings | purchase | restore */
        @JavascriptInterface
        public void billing(final String action, final String payload, final String cb) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (billing != null) billing.handle(action, payload, cb);
                }
            });
        }
    }

    // ───────── اختيار ملف النسخة الاحتياطية (input type=file) ─────────
    final class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(Intent.createChooser(i, "اختر ملف النسخة الاحتياطية"), REQ_FILE);
                return true;
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
        }
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_FILE) return;
        ValueCallback<Uri[]> cb = fileCallback;
        fileCallback = null;
        if (cb == null) return;
        Uri[] value = null;
        if (result == RESULT_OK && data != null) {
            if (data.getData() != null) {
                value = new Uri[]{data.getData()};
            } else if (data.getClipData() != null && data.getClipData().getItemCount() > 0) {
                value = new Uri[]{data.getClipData().getItemAt(0).getUri()};
            }
        }
        cb.onReceiveValue(value);
    }

    // ───────── تحميل ملفات التطبيق من جوه الـAPK ─────────
    final class LocalClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u == null || !HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null || path.isEmpty() || "/".equals(path)) path = "/index.html";
            if (path.contains("..")) return notFound();
            try {
                InputStream in = getAssets().open("www" + path);
                WebResourceResponse r = new WebResourceResponse(mime(path), "UTF-8", in);
                Map<String, String> h = new HashMap<String, String>();
                h.put("Cache-Control", "no-cache");
                r.setResponseHeaders(h);
                return r;
            } catch (IOException e) {
                return notFound();
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (u != null && HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (Exception ignored) {
            }
            return true;
        }
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    static String mime(String p) {
        String l = p.toLowerCase(Locale.ROOT);
        if (l.endsWith(".html")) return "text/html";
        if (l.endsWith(".js") || l.endsWith(".mjs")) return "text/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".woff2")) return "font/woff2";
        if (l.endsWith(".woff")) return "font/woff";
        if (l.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    // ───────── دورة حياة الشاشة ─────────
    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (billing != null) {
            billing.end();
            billing = null;
        }
        if (web != null) {
            web.removeJavascriptInterface("GameyatiNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    // ───────── أكواد خاصة بإصدارات أندرويد الجديدة ─────────
    @android.annotation.TargetApi(30)
    static final class Api30 {
        static void edgeToEdge(Window w, View root) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                // أيقونات شريط الحالة داكنة (الخلفية فاتحة)
                int light = android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(light, light);
            }
            root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    android.graphics.Insets i = insets.getInsets(
                            WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                    return WindowInsets.CONSUMED;
                }
            });
        }
    }

    @android.annotation.TargetApi(33)
    static final class Api33 {
        static void registerBack(final MainActivity a) {
            a.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    new android.window.OnBackInvokedCallback() {
                        @Override
                        public void onBackInvoked() {
                            a.handleBack();
                        }
                    });
        }
    }
}
