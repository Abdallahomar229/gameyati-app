package com.gameyati.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * تنبيهات المواعيد (من غير سيرفر): الجافاسكريبت بتبعت قايمة المواعيد الجاية،
 * وإحنا بنجدولها في AlarmManager (مواعيد تقريبية — مش محتاجة إذن خاص)،
 * وبنعيد جدولتها بعد إعادة تشغيل الجهاز أو تحديث التطبيق.
 */
public final class ReminderReceiver extends BroadcastReceiver {
    static final String PREFS = "reminders";
    static final String KEY_ITEMS = "items";
    static final String KEY_CODES = "codes";
    static final String CHANNEL = "dates";
    static final String ACTION_FIRE = "com.gameyati.app.REMIND";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_FIRE.equals(a)) {
            show(ctx, intent.getIntExtra("code", 1), intent.getStringExtra("title"), intent.getStringExtra("body"));
        } else if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            setAll(ctx, p.getString(KEY_ITEMS, "[]"));
        }
    }

    static int codeFor(String id) {
        return (id == null ? 0 : id.hashCode()) & 0x7fffffff;
    }

    static PendingIntent pending(Context ctx, int code, String title, String body) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        i.setAction(ACTION_FIRE);
        i.putExtra("code", code);
        if (title != null) i.putExtra("title", title);
        if (body != null) i.putExtra("body", body);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** بيلغي كل التنبيهات القديمة ويجدول الجديدة */
    static synchronized void setAll(Context ctx, String json) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        SharedPreferences p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            JSONArray old = new JSONArray(p.getString(KEY_CODES, "[]"));
            for (int k = 0; k < old.length(); k++) {
                am.cancel(pending(ctx, old.getInt(k), null, null));
            }
        } catch (Exception ignored) {
        }
        JSONArray codes = new JSONArray();
        JSONArray keep = new JSONArray();
        long now = System.currentTimeMillis();
        try {
            JSONArray items = new JSONArray(json == null ? "[]" : json);
            for (int k = 0; k < items.length() && k < 60; k++) {
                JSONObject o = items.getJSONObject(k);
                long at = o.optLong("at", 0);
                if (at <= now) continue;
                int code = codeFor(o.optString("id"));
                PendingIntent pi = pending(ctx, code, o.optString("title"), o.optString("body"));
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                codes.put(code);
                keep.put(o);
            }
        } catch (Exception ignored) {
        }
        p.edit().putString(KEY_CODES, codes.toString()).putString(KEY_ITEMS, keep.toString()).apply();
    }

    static void show(Context ctx, int code, String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            Notification.Builder b;
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "مواعيد الجمعيات", NotificationManager.IMPORTANCE_DEFAULT);
                ch.setDescription("تذكير بمواعيد الدفع والقبض");
                nm.createNotificationChannel(ch);
                b = new Notification.Builder(ctx, CHANNEL);
            } else {
                b = new Notification.Builder(ctx);
            }
            Intent open = new Intent(ctx, MainActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent tap = PendingIntent.getActivity(ctx, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            b.setSmallIcon(R.drawable.ic_stat)
                    .setColor(0xFF4F35B8)
                    .setContentTitle(title == null ? "جمعيتي" : title)
                    .setContentText(body == null ? "" : body)
                    .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
                    .setAutoCancel(true)
                    .setContentIntent(tap);
            nm.notify(code, b.build());
        } catch (Throwable ignored) {
        }
    }
}
