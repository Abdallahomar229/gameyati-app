import UIKit
import UserNotifications

/// «جمعيتي» — غلاف آيفون بسيط: WKWebView بيعرض التطبيق من ملفاته (من غير إنترنت)،
/// وجسر للجافاسكريبت بنفس أسماء نسخة أندرويد (GameyatiNative): المشاركة، واتساب، التنبيهات، PDF، «بلس»، الإعلانات.
@main
final class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = GameyatiTheme.paper
        w.rootViewController = WebViewController()
        w.makeKeyAndVisible()
        window = w
        return true
    }

    // التنبيه يظهر حتى لو التطبيق مفتوح
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        if #available(iOS 14.0, *) {
            completionHandler([.banner, .list, .sound])
        } else {
            completionHandler([.alert, .sound])
        }
    }
}

enum GameyatiTheme {
    static let paper = UIColor(red: 246.0 / 255.0, green: 244.0 / 255.0, blue: 251.0 / 255.0, alpha: 1)
}
