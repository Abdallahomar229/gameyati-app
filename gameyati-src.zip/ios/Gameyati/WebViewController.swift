import UIKit
import WebKit
import UserNotifications

/// الشاشة الوحيدة في التطبيق: واجهة «جمعيتي» جوه WKWebView.
final class WebViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, UIScrollViewDelegate {

    static let scheme = "app"
    static let startURL = URL(string: "app://gameyati/index.html")!

    private var web: WKWebView!
    private let store = StoreBridge()
    private lazy var ads = AdsBridge(host: self) { [weak self] shown in
        self?.js("window.__gamAdDone&&window.__gamAdDone(\(shown ? "true" : "false"))")
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        if #available(iOS 13.0, *) { return .darkContent }
        return .default
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .portrait }

    override func loadView() {
        let config = WKWebViewConfiguration()
        config.setURLSchemeHandler(BundleSchemeHandler(), forURLScheme: WebViewController.scheme)
        if #available(iOS 16.4, *) {
            config.preferences.shouldPrintBackgrounds = true
        }

        let content = WKUserContentController()
        content.addUserScript(WKUserScript(source: bridgeScript(),
                                           injectionTime: .atDocumentStart,
                                           forMainFrameOnly: true))
        content.add(WeakScriptHandler(self), name: "gameyati")
        config.userContentController = content

        let w = WKWebView(frame: .zero, configuration: config)
        w.isOpaque = false
        w.backgroundColor = GameyatiTheme.paper
        w.scrollView.backgroundColor = GameyatiTheme.paper
        w.scrollView.bounces = false
        w.scrollView.alwaysBounceVertical = false
        w.scrollView.contentInsetAdjustmentBehavior = .never
        w.scrollView.delegate = self
        w.allowsBackForwardNavigationGestures = false
        w.allowsLinkPreview = false
        w.navigationDelegate = self
        w.uiDelegate = self
        web = w
        view = w
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        store.onEntitlement = { [weak self] on in
            self?.js("window.__gamEntitlement&&window.__gamEntitlement(\(on ? "true" : "false"))")
        }
        store.start()
        web.load(URLRequest(url: WebViewController.startURL))
    }

    // منع التكبير بإصبعين (الواجهة مصممة لمقاس الشاشة)
    func viewForZooming(in scrollView: UIScrollView) -> UIView? { nil }

    // MARK: - الجسر (نفس أسماء نسخة أندرويد)

    private func bridgeScript() -> String {
        """
        (function () {
          if (window.GameyatiNative) return;
          var post = function (m) {
            try { window.webkit.messageHandlers.gameyati.postMessage(m); } catch (e) {}
          };
          window.GameyatiNative = {
            platform: function () { return 'ios'; },
            vibrate: function (ms) { post({ fn: 'vibrate', ms: Number(ms) || 0 }); },
            pdf: function (a, name, cb) { post({ fn: 'pdf', action: String(a), name: String(name || 'Gameyati'), cb: String(cb) }); },
            shareFile: function (b64, mime, name, title, cb) { post({ fn: 'shareFile', b64: String(b64), mime: String(mime || ''), name: String(name || 'file'), title: String(title || ''), cb: String(cb) }); },
            shareText: function (text, title, cb) { post({ fn: 'shareText', text: String(text || ''), title: String(title || ''), cb: String(cb) }); },
            open: function (url) { post({ fn: 'open', url: String(url || '') }); },
            notify: function (a, json) { post({ fn: 'notify', action: String(a), json: String(json || '[]') }); },
            notifyPermission: function (cb) { post({ fn: 'notifyPermission', cb: String(cb) }); },
            ads: function (a) { post({ fn: 'ads', action: String(a) }); },
            billing: function (a, p, cb) { post({ fn: 'billing', action: String(a), payload: String(p || '{}'), cb: String(cb) }); }
          };
        })();
        """
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any], let fn = body["fn"] as? String else { return }
        switch fn {
        case "pdf":
            let cb = body["cb"] as? String ?? ""
            let name = WebViewController.safeName(body["name"] as? String ?? "Gameyati")
            if (body["action"] as? String) == "print" { printDialog(name: name, cb: cb) } else { sharePDF(name: name, cb: cb) }
        case "shareFile":
            shareFile(b64: body["b64"] as? String ?? "", name: body["name"] as? String ?? "file", cb: body["cb"] as? String ?? "")
        case "shareText":
            shareText(body["text"] as? String ?? "", cb: body["cb"] as? String ?? "")
        case "open":
            if let s = body["url"] as? String, let url = URL(string: s) { UIApplication.shared.open(url) }
        case "notify":
            if (body["action"] as? String) == "set" { Reminders.set(json: body["json"] as? String ?? "[]") }
        case "notifyPermission":
            let cb = body["cb"] as? String ?? ""
            Reminders.ask { [weak self] granted in
                self?.reply("__gamReply", cb: cb, result: ["ok": true, "granted": granted])
            }
        case "ads":
            if (body["action"] as? String) == "interstitial" { ads.show() } else { ads.start() }
        case "vibrate":
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case "billing":
            let cb = body["cb"] as? String ?? ""
            store.handle(action: body["action"] as? String ?? "",
                         payload: body["payload"] as? String ?? "{}") { [weak self] result in
                self?.reply("__gamBilling", cb: cb, result: result)
            }
        default:
            break
        }
    }

    private func reply(_ fn: String, cb: String, result: [String: Any]) {
        let json: String
        if let data = try? JSONSerialization.data(withJSONObject: result),
           let text = String(data: data, encoding: .utf8) {
            json = text
        } else {
            json = "{\"ok\":false,\"reason\":\"error\"}"
        }
        js("window.\(fn)&&window.\(fn)(\(WebViewController.jsString(cb)),\(WebViewController.jsString(json)))")
    }

    // MARK: - PDF

    static func safeName(_ s: String) -> String {
        let bad = CharacterSet(charactersIn: "\\/:*?\"<>|\n\r\t")
        var n = s.components(separatedBy: bad).joined(separator: " ").trimmingCharacters(in: .whitespaces)
        if n.isEmpty { n = "Gameyati" }
        return String(n.prefix(80))
    }

    /// صفحة A4 بهوامش ~12 مم (التقرير بيتوزّع على صفحات لوحده)
    private final class A4Renderer: UIPrintPageRenderer {
        static let paper = CGRect(x: 0, y: 0, width: 595.2, height: 841.8)
        override var paperRect: CGRect { A4Renderer.paper }
        override var printableRect: CGRect { A4Renderer.paper.insetBy(dx: 34, dy: 38) }
    }

    private func makePDF(name: String) -> URL? {
        let renderer = A4Renderer()
        renderer.addPrintFormatter(web.viewPrintFormatter(), startingAtPageAt: 0)
        let pages = renderer.numberOfPages
        guard pages > 0 else { return nil }
        let data = NSMutableData()
        let info: [String: Any] = [kCGPDFContextTitle as String: name, kCGPDFContextCreator as String: "Gameyati"]
        UIGraphicsBeginPDFContextToData(data, A4Renderer.paper, info)
        renderer.prepare(forDrawingPages: NSRange(location: 0, length: pages))
        let bounds = UIGraphicsGetPDFContextBounds()
        for i in 0..<pages {
            UIGraphicsBeginPDFPage()
            renderer.drawPage(at: i, in: bounds)
        }
        UIGraphicsEndPDFContext()
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("pdf", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("\(name).pdf")
        do {
            try data.write(to: url, options: .atomic)
            return url
        } catch {
            return nil
        }
    }

    private func sharePDF(name: String, cb: String) {
        guard let url = makePDF(name: name) else {
            reply("__gamReply", cb: cb, result: ["ok": false, "reason": "render"])
            return
        }
        let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let pop = sheet.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 80, width: 1, height: 1)
        }
        present(sheet, animated: true)
        reply("__gamReply", cb: cb, result: ["ok": true])
    }

    // MARK: - المشاركة (صورة الجدول / النسخة الاحتياطية / نص)

    private func presentShare(_ items: [Any]) {
        let sheet = UIActivityViewController(activityItems: items, applicationActivities: nil)
        if let pop = sheet.popoverPresentationController {
            pop.sourceView = view
            pop.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.maxY - 80, width: 1, height: 1)
        }
        present(sheet, animated: true)
    }

    private func shareFile(b64: String, name: String, cb: String) {
        guard let data = Data(base64Encoded: b64, options: .ignoreUnknownCharacters) else {
            reply("__gamReply", cb: cb, result: ["ok": false, "reason": "data"])
            return
        }
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("share", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent(WebViewController.safeName(name))
        do {
            try data.write(to: url, options: .atomic)
        } catch {
            reply("__gamReply", cb: cb, result: ["ok": false, "reason": "write"])
            return
        }
        presentShare([url])
        reply("__gamReply", cb: cb, result: ["ok": true])
    }

    private func shareText(_ text: String, cb: String) {
        presentShare([text])
        reply("__gamReply", cb: cb, result: ["ok": true])
    }

    private func printDialog(name: String, cb: String) {
        let pc = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.jobName = name
        info.outputType = .general
        pc.printInfo = info
        pc.printFormatter = web.viewPrintFormatter()
        pc.present(animated: true) { [weak self] _, completed, _ in
            self?.reply("__gamReply", cb: cb, result: ["ok": true, "reason": completed ? "printed" : "cancel"])
        }
    }

    // MARK: - اللينكات اللي برا التطبيق بتفتح في Safari

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else {
            decisionHandler(.cancel)
            return
        }
        if url.scheme == WebViewController.scheme || url.scheme == "about" || url.scheme == "blob" || url.scheme == "data" {
            decisionHandler(.allow)
            return
        }
        if ["http", "https", "mailto", "tel", "whatsapp"].contains(url.scheme ?? "") {
            UIApplication.shared.open(url)
        }
        decisionHandler(.cancel)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = navigationAction.request.url, url.scheme == "http" || url.scheme == "https" || url.scheme == "mailto" {
            UIApplication.shared.open(url)
        }
        return nil
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.load(URLRequest(url: WebViewController.startURL))
    }

    // MARK: - مساعدات

    private func js(_ code: String) {
        DispatchQueue.main.async { [weak self] in
            self?.web?.evaluateJavaScript(code, completionHandler: nil)
        }
    }

    /// نص جافاسكريبت آمن ("...") من أي نص
    static func jsString(_ s: String) -> String {
        if let data = try? JSONSerialization.data(withJSONObject: [s]),
           let text = String(data: data, encoding: .utf8), text.count >= 2 {
            return String(text.dropFirst().dropLast())
        }
        return "\"\""
    }
}

/// WKUserContentController بيمسك الـhandler بقوة، فبنحط وسيط ضعيف عشان منعملش دايرة.
final class WeakScriptHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?

    init(_ target: WKScriptMessageHandler) {
        self.target = target
        super.init()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

/// بيقدّم ملفات الواجهة من جوه التطبيق على app://gameyati/… (عشان الـmodules وlocalStorage يشتغلوا عادي)
final class BundleSchemeHandler: NSObject, WKURLSchemeHandler {
    private let root: URL = (Bundle.main.resourceURL ?? Bundle.main.bundleURL)
        .appendingPathComponent("web", isDirectory: true)
        .standardizedFileURL

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let url = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }
        var path = url.path
        if path.isEmpty || path == "/" { path = "/index.html" }
        let file = root.appendingPathComponent(String(path.dropFirst())).standardizedFileURL
        guard file.path.hasPrefix(root.path), let data = try? Data(contentsOf: file) else {
            let missing = HTTPURLResponse(url: url, statusCode: 404, httpVersion: "HTTP/1.1",
                                          headerFields: ["Content-Type": "text/plain"])!
            urlSchemeTask.didReceive(missing)
            urlSchemeTask.didReceive(Data())
            urlSchemeTask.didFinish()
            return
        }
        let headers = [
            "Content-Type": BundleSchemeHandler.mime(file.pathExtension),
            "Content-Length": String(data.count),
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*",
        ]
        let response = HTTPURLResponse(url: url, statusCode: 200, httpVersion: "HTTP/1.1", headerFields: headers)!
        urlSchemeTask.didReceive(response)
        urlSchemeTask.didReceive(data)
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {}

    static func mime(_ ext: String) -> String {
        switch ext.lowercased() {
        case "html", "htm": return "text/html; charset=utf-8"
        case "js", "mjs": return "text/javascript; charset=utf-8"
        case "css": return "text/css; charset=utf-8"
        case "json": return "application/json; charset=utf-8"
        case "svg": return "image/svg+xml"
        case "png": return "image/png"
        case "jpg", "jpeg": return "image/jpeg"
        case "webp": return "image/webp"
        case "gif": return "image/gif"
        case "woff2": return "font/woff2"
        case "woff": return "font/woff"
        case "ttf": return "font/ttf"
        case "ico": return "image/x-icon"
        case "txt": return "text/plain; charset=utf-8"
        default: return "application/octet-stream"
        }
    }
}

/// تنبيهات المواعيد (محلية على الجهاز — من غير سيرفر)
enum Reminders {
    static func ask(_ done: @escaping (Bool) -> Void) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            DispatchQueue.main.async { done(granted) }
        }
    }

    /// json = [{ id, at (ms), title, body }] — بيستبدل كل اللي قبله
    static func set(json: String) {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        guard let data = json.data(using: .utf8),
              let items = (try? JSONSerialization.jsonObject(with: data)) as? [[String: Any]] else { return }
        center.getNotificationSettings { settings in
            guard settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional else { return }
            let now = Date()
            for item in items.prefix(60) {
                guard let id = item["id"] as? String, let ms = (item["at"] as? NSNumber)?.doubleValue else { continue }
                let date = Date(timeIntervalSince1970: ms / 1000)
                if date <= now { continue }
                let content = UNMutableNotificationContent()
                content.title = item["title"] as? String ?? "جمعيتي"
                content.body = item["body"] as? String ?? ""
                content.sound = .default
                let comps = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: date)
                let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
            }
        }
    }
}
