import { AppProvider } from './state/app.jsx'
import { NavProvider, useNav } from './state/nav.jsx'
import { Toast } from './components/ui.jsx'
import Home from './screens/Home.jsx'
import OrgEdit from './screens/OrgEdit.jsx'
import Order from './screens/Order.jsx'
import Gam from './screens/Gam.jsx'
import JoinEdit from './screens/JoinEdit.jsx'
import Joined from './screens/Joined.jsx'
import Share from './screens/Share.jsx'
import Archive from './screens/Archive.jsx'
import Paywall from './screens/Paywall.jsx'
import Settings from './screens/Settings.jsx'
import Privacy from './screens/Privacy.jsx'

function Router() {
  const { route, depth } = useNav()
  const key = `${depth}-${route.name}-${route.id || ''}`
  switch (route.name) {
    case 'orgEdit':
      return <OrgEdit key={key} id={route.id} />
    case 'order':
      return <Order key={key} id={route.id} fresh={route.fresh} />
    case 'gam':
      return <Gam key={key} id={route.id} round={route.round} />
    case 'joinEdit':
      return <JoinEdit key={key} id={route.id} />
    case 'joined':
      return <Joined key={key} id={route.id} />
    case 'share':
      return <Share key={key} id={route.id} />
    case 'archive':
      return <Archive key={key} />
    case 'paywall':
      return <Paywall key={key} reason={route.reason} />
    case 'settings':
      return <Settings key={key} />
    case 'privacy':
      return <Privacy key={key} />
    default:
      return <Home key={key} />
  }
}

export default function App() {
  return (
    <AppProvider>
      <NavProvider>
        <Router />
        <Toast />
      </NavProvider>
    </AppProvider>
  )
}
