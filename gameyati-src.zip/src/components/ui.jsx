// مكوّنات الواجهة المشتركة
import { useEffect, useId, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { useNav } from '../state/nav.jsx'
import { useApp } from '../state/app.jsx'
import { Icon } from './Icons.jsx'

export function Screen({ title, sub, children, actions, right, noBack, className = '', bodyRef, onBack }) {
  const nav = useNav()
  return (
    <div className={`screen ${className}`}>
      <header className="topbar">
        {!noBack ? (
          <button type="button" className="icon-btn" aria-label="رجوع" onClick={onBack || nav.back}>
            <Icon name="back" />
          </button>
        ) : (
          <span className="topbar-gap" />
        )}
        <div className="topbar-title">
          <h1>{title}</h1>
          {sub ? <span className="topbar-sub">{sub}</span> : null}
        </div>
        <div className="topbar-right">{right}</div>
      </header>
      <main className="screen-body" ref={bodyRef}>
        {children}
      </main>
      {actions ? <footer className="screen-actions">{actions}</footer> : null}
    </div>
  )
}

export function Field({ label, hint, value, onChange, type = 'text', placeholder, dir, inputMode, autoComplete, maxLength, children, className = '' }) {
  const id = useId()
  return (
    <div className={`field ${className}`}>
      {label ? <label htmlFor={id}>{label}</label> : null}
      {children || (
        <input
          id={id}
          type={type}
          value={value}
          dir={dir}
          inputMode={inputMode}
          autoComplete={autoComplete || 'off'}
          maxLength={maxLength}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {hint ? <span className="field-hint">{hint}</span> : null}
    </div>
  )
}

export function TextArea({ label, value, onChange, placeholder, rows = 5, dir, counter, hint, tools }) {
  const id = useId()
  const ref = useRef(null)
  // الطول بيكبر مع الكلام
  useEffect(() => {
    const el = ref.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = `${Math.max(el.scrollHeight + 2, rows * 26)}px`
  }, [value, rows])
  const n = (value || '').trim().length
  return (
    <div className="field">
      {label || tools ? (
        <div className="field-head">
          {label ? <label htmlFor={id}>{label}</label> : <span />}
          {tools}
        </div>
      ) : null}
      <textarea id={id} ref={ref} value={value} dir={dir} rows={rows} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
      {counter || hint ? (
        <div className="field-foot">
          <span className="field-hint">{hint}</span>
          {counter ? (
            <span className={`counter ${n && (n < counter[0] || n > counter[1]) ? 'warn' : n ? 'ok' : ''}`}>
              {n} / {counter[1]}
            </span>
          ) : null}
        </div>
      ) : null}
    </div>
  )
}

export function Toggle({ label, checked, onChange, sub }) {
  return (
    <button type="button" role="switch" aria-checked={checked} className={`toggle-row ${checked ? 'on' : ''}`} onClick={() => onChange(!checked)}>
      <span className="toggle-text">
        <span>{label}</span>
        {sub ? <small>{sub}</small> : null}
      </span>
      <span className="switch" aria-hidden="true">
        <span />
      </span>
    </button>
  )
}

export function Segmented({ options, value, onChange, className = '' }) {
  return (
    <div className={`seg ${className}`} role="radiogroup">
      {options.map((o) => (
        <button key={o.value} type="button" role="radio" aria-checked={value === o.value} className={value === o.value ? 'on' : ''} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  )
}

// لوحة من تحت (Bottom sheet)
export function Sheet({ open, onClose, title, children, footer, tall }) {
  const [shown, setShown] = useState(open)
  useEffect(() => {
    if (open) setShown(true)
    else {
      const t = setTimeout(() => setShown(false), 220)
      return () => clearTimeout(t)
    }
    return undefined
  }, [open])
  if (!shown) return null
  return createPortal(
    <div className={`sheet-wrap ${open ? 'in' : 'out'}`} onClick={onClose}>
      <div className={`sheet ${tall ? 'tall' : ''}`} role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-grip" />
        {title ? (
          <div className="sheet-head">
            <h2>{title}</h2>
            <button type="button" className="icon-btn sm" aria-label="إغلاق" onClick={onClose}>
              <Icon name="close" size={20} />
            </button>
          </div>
        ) : null}
        <div className="sheet-body">{children}</div>
        {footer ? <div className="sheet-foot">{footer}</div> : null}
      </div>
    </div>,
    document.body,
  )
}

export function Confirm({ open, title, text, yes = 'تأكيد', no = 'إلغاء', danger, onYes, onNo }) {
  return (
    <Sheet open={open} onClose={onNo} title={title}>
      {text ? <p className="confirm-text">{text}</p> : null}
      <div className="row-btns">
        <button type="button" className={`btn ${danger ? 'btn-danger' : 'btn-primary'}`} onClick={onYes}>
          {yes}
        </button>
        <button type="button" className="btn btn-ghost" onClick={onNo}>
          {no}
        </button>
      </div>
    </Sheet>
  )
}

export function Toast() {
  const { toastState } = useApp()
  if (!toastState) return null
  return (
    <div className="toast" role="status" key={toastState.id}>
      {toastState.msg}
    </div>
  )
}

export function Tip({ children }) {
  if (!children) return null
  return (
    <div className="tip">
      <Icon name="bulb" size={18} />
      <p>{children}</p>
    </div>
  )
}

export function PlusBadge({ small }) {
  return (
    <span className={`plus-badge ${small ? 'sm' : ''}`}>
      <Icon name="crown" size={small ? 11 : 13} stroke={2.2} /> بلس
    </span>
  )
}

export function Ring({ value, size = 64, stroke = 6 }) {
  const r = (size - stroke) / 2
  const c = 2 * Math.PI * r
  return (
    <svg className="ring" width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--line)" strokeWidth={stroke} />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={r}
        fill="none"
        stroke="currentColor"
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - Math.max(0, Math.min(100, value)) / 100)}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text x="50%" y="52%" dominantBaseline="middle" textAnchor="middle" className="ring-num">
        {value}%
      </text>
    </svg>
  )
}
