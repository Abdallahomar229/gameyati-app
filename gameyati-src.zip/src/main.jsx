import { createRoot } from 'react-dom/client'
import './styles/fonts.css'
import './styles/app.css'
import App from './App.jsx'
import { initNative } from './lib/native.js'

initNative()
createRoot(document.getElementById('root')).render(<App />)
