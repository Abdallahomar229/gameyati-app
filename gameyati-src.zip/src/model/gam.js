// نموذج «الجمعية» وكل الحسابات عليها
//
// جمعية بنظّمها (kind = 'org'):
//   members: [{ id, name, phone, shares }]   shares = 0.5 | 1 | 2 | 3 …
//   turns:   [{ id, holders: [{ m, f }] }]   كل عنصر = دور واحد بالترتيب (f = 1 سهم كامل، 0.5 نص سهم)
//   payments: { [roundIndex]: { [memberId]: { amt, at } } }
//   paidOut:  { [roundIndex]: at }
//
// جمعية أنا مشترك فيها (kind = 'member'):
//   amount = قسطي في كل دور، rounds = عدد الأدوار، myTurn = رقم دوري (من 1)
//   paid: { [roundIndex]: at }، received: at | 0

export const CURRENCIES = [
  { code: 'EGP', label: 'جنيه مصري', short: 'ج.م' },
  { code: 'SAR', label: 'ريال سعودي', short: 'ر.س' },
  { code: 'AED', label: 'درهم إماراتي', short: 'د.إ' },
  { code: 'KWD', label: 'دينار كويتي', short: 'د.ك' },
  { code: 'QAR', label: 'ريال قطري', short: 'ر.ق' },
  { code: 'BHD', label: 'دينار بحريني', short: 'د.ب' },
  { code: 'OMR', label: 'ريال عماني', short: 'ر.ع' },
  { code: 'JOD', label: 'دينار أردني', short: 'د.أ' },
  { code: 'IQD', label: 'دينار عراقي', short: 'د.ع' },
  { code: 'LYD', label: 'دينار ليبي', short: 'د.ل' },
  { code: 'TND', label: 'دينار تونسي', short: 'د.ت' },
  { code: 'DZD', label: 'دينار جزائري', short: 'د.ج' },
  { code: 'MAD', label: 'درهم مغربي', short: 'د.م' },
  { code: 'SDG', label: 'جنيه سوداني', short: 'ج.س' },
  { code: 'USD', label: 'دولار أمريكي', short: '$' },
]

export const FREQS = [
  { value: 'month', label: 'شهري', unit: 'شهر', units: 'شهور', every: 'كل شهر' },
  { value: 'week', label: 'أسبوعي', unit: 'أسبوع', units: 'أسابيع', every: 'كل أسبوع' },
  { value: 'biweek', label: 'كل أسبوعين', unit: 'أسبوعين', units: 'أسبوعين', every: 'كل أسبوعين' },
]

export const SHARE_OPTIONS = [
  { value: 0.5, label: 'نصف سهم' },
  { value: 1, label: 'سهم' },
  { value: 2, label: 'سهمين' },
  { value: 3, label: '3 أسهم' },
]

export function uid(prefix = 'x') {
  return `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`
}

// ───────── التواريخ (yyyy-mm-dd بتوقيت الجهاز) ─────────
export function todayISO(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export function parseISO(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''))
  if (!m) return new Date()
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]))
}

function addMonths(d, n) {
  const day = d.getDate()
  const r = new Date(d.getFullYear(), d.getMonth() + n, 1)
  const last = new Date(r.getFullYear(), r.getMonth() + 1, 0).getDate()
  r.setDate(Math.min(day, last))
  return r
}

// تاريخ الدور رقم i (من صفر)
export function roundDate(start, freq, i) {
  const d = parseISO(start)
  if (freq === 'week') return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 7 * i)
  if (freq === 'biweek') return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 14 * i)
  return addMonths(d, i)
}

export function roundISO(start, freq, i) {
  return todayISO(roundDate(start, freq, i))
}

// عدد الأيام من النهارده لحد التاريخ (سالب = فات)
export function daysUntil(iso, now = new Date()) {
  const a = parseISO(todayISO(now))
  const b = parseISO(iso)
  return Math.round((b - a) / 86400000)
}

// ───────── إنشاء ─────────
export function blankOrg(currency = 'EGP') {
  return {
    id: uid('g'),
    kind: 'org',
    name: '',
    amount: '',
    currency,
    freq: 'month',
    start: todayISO(),
    members: [],
    turns: [],
    payments: {},
    paidOut: {},
    note: '',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
}

export function blankJoined(currency = 'EGP') {
  return {
    id: uid('g'),
    kind: 'member',
    name: '',
    organizer: '',
    amount: '',
    rounds: 10,
    myTurn: 1,
    currency,
    freq: 'month',
    start: todayISO(),
    paid: {},
    received: 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
}

export function normalize(g) {
  if (!g || typeof g !== 'object') return null
  if (g.kind === 'member') {
    const base = blankJoined()
    return {
      ...base,
      ...g,
      amount: num(g.amount),
      rounds: clampInt(g.rounds, 1, 120, 10),
      myTurn: clampInt(g.myTurn, 1, 120, 1),
      paid: obj(g.paid),
    }
  }
  const base = blankOrg()
  const members = Array.isArray(g.members)
    ? g.members.filter((m) => m && m.id).map((m) => ({ id: m.id, name: String(m.name || ''), phone: String(m.phone || ''), shares: validShares(m.shares) }))
    : []
  const turns = Array.isArray(g.turns)
    ? g.turns
        .filter((t) => t && t.id && Array.isArray(t.holders))
        .map((t) => ({ id: t.id, holders: t.holders.filter((h) => h && h.m).map((h) => ({ m: h.m, f: h.f === 0.5 ? 0.5 : 1 })) }))
    : []
  return { ...base, ...g, kind: 'org', amount: num(g.amount), members, turns, payments: obj(g.payments), paidOut: obj(g.paidOut) }
}

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) && n > 0 ? n : 0
}
function obj(v) {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : {}
}
function clampInt(v, a, b, d) {
  const n = Math.round(Number(v))
  return Number.isFinite(n) ? Math.min(b, Math.max(a, n)) : d
}
function validShares(s) {
  const n = Number(s)
  if (n === 0.5) return 0.5
  if (Number.isFinite(n) && n >= 1) return Math.min(10, Math.round(n))
  return 1
}

// ───────── الأدوار (توزيع الأسهم على الأدوار) ─────────
// بتحافظ على ترتيب الأدوار الموجودة، وتضيف الجديد في الآخر، وتشيل اللي اتمسح،
// وتجمع كل نصّين سهم في دور واحد.
export function syncTurns(g) {
  const want = new Map(g.members.map((m) => [m.id, { full: Math.floor(m.shares), half: m.shares % 1 ? 1 : 0 }]))
  const used = new Map(g.members.map((m) => [m.id, { full: 0, half: 0 }]))
  const turns = []
  for (const t of g.turns) {
    const holders = []
    for (const h of t.holders) {
      const w = want.get(h.m)
      const u = used.get(h.m)
      if (!w) continue
      if (h.f === 1 && u.full < w.full) {
        u.full++
        holders.push(h)
      } else if (h.f === 0.5 && u.half < w.half) {
        u.half++
        holders.push(h)
      }
    }
    // دور كامل لازم يكون سهم واحد أو نصّين
    if (holders.length === 1 && holders[0].f === 1) turns.push({ id: t.id, holders })
    else if (holders.length && holders.every((h) => h.f === 0.5)) turns.push({ id: t.id, holders: holders.slice(0, 2) })
    else if (holders.length) {
      // خليط غريب: نفصله
      for (const h of holders) turns.push({ id: uid('t'), holders: [h] })
    }
  }
  for (const m of g.members) {
    const w = want.get(m.id)
    const u = used.get(m.id)
    for (let i = u.full; i < w.full; i++) turns.push({ id: uid('t'), holders: [{ m: m.id, f: 1 }] })
    if (w.half && !u.half) {
      const open = turns.find((t) => t.holders.length === 1 && t.holders[0].f === 0.5 && t.holders[0].m !== m.id)
      if (open) open.holders.push({ m: m.id, f: 0.5 })
      else turns.push({ id: uid('t'), holders: [{ m: m.id, f: 0.5 }] })
    }
  }
  return { ...g, turns }
}

// دور فيه نص سهم من غير شريك
export function openHalfTurns(g) {
  return g.turns.filter((t) => t.holders.length === 1 && t.holders[0].f === 0.5)
}

export function shuffleTurns(turns) {
  const a = turns.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// ───────── الحسابات ─────────
export function memberMap(g) {
  return new Map(g.members.map((m) => [m.id, m]))
}

export function totalShares(g) {
  return g.members.reduce((s, m) => s + m.shares, 0)
}

export function roundsCount(g) {
  return g.kind === 'member' ? g.rounds : g.turns.length
}

// قسط العضو في كل دور
export function dueOf(g, m) {
  return m.shares * g.amount
}

// القبض في كل دور
export function potOf(g) {
  if (g.kind === 'member') return g.amount * g.rounds
  return totalShares(g) * g.amount
}

export function turnNames(g, turn, map = memberMap(g)) {
  if (!turn) return ''
  return turn.holders.map((h) => map.get(h.m)?.name || '—').join(' + ')
}

export function paidIn(g, i, memberId) {
  return Number(g.payments?.[i]?.[memberId]?.amt) || 0
}

export function roundCollected(g, i) {
  const p = g.payments?.[i] || {}
  return Object.values(p).reduce((s, x) => s + (Number(x?.amt) || 0), 0)
}

// حالة العضو في دور معيّن: paid | partial | late | due | upcoming
export function memberStatus(g, i, m, today = todayISO()) {
  const due = dueOf(g, m)
  const paid = paidIn(g, i, m.id)
  if (paid >= due - 0.001) return 'paid'
  const d = daysUntil(roundISO(g.start, g.freq, i), parseISO(today))
  if (paid > 0) return d < 0 ? 'late' : 'partial'
  if (d < 0) return 'late'
  if (d === 0) return 'due'
  return 'upcoming'
}

// الدور «الحالي»: آخر دور ميعاده جه، أو الأول لو لسه مبدأتش
export function currentRound(g, today = todayISO()) {
  const n = roundsCount(g)
  if (!n) return 0
  let cur = 0
  for (let i = 0; i < n; i++) {
    if (daysUntil(roundISO(g.start, g.freq, i), parseISO(today)) <= 0) cur = i
    else break
  }
  return cur
}

export function isFinished(g, today = todayISO()) {
  const n = roundsCount(g)
  if (!n) return false
  const last = roundISO(g.start, g.freq, n - 1)
  if (daysUntil(last, parseISO(today)) > 0) return false
  if (g.kind === 'member') return !!g.received && Object.keys(g.paid || {}).length >= n
  for (let i = 0; i < n; i++) if (!g.paidOut?.[i]) return false
  return true
}

// كل الأعضاء المتأخرين (في أي دور فات) مع المبلغ الناقص
export function lateList(g, today = todayISO()) {
  if (g.kind !== 'org') return []
  const out = []
  const n = roundsCount(g)
  for (const m of g.members) {
    let missing = 0
    const rounds = []
    for (let i = 0; i < n; i++) {
      const d = daysUntil(roundISO(g.start, g.freq, i), parseISO(today))
      if (d > 0) break
      const left = dueOf(g, m) - paidIn(g, i, m.id)
      if (left > 0.001 && d < 0) {
        missing += left
        rounds.push(i)
      }
    }
    if (missing > 0) out.push({ m, missing, rounds })
  }
  return out
}

// إجمالي اللي دفعه العضو واللي عليه لحد النهارده
export function memberTotals(g, m, today = todayISO()) {
  const n = roundsCount(g)
  let paid = 0
  let dueSoFar = 0
  for (let i = 0; i < n; i++) {
    paid += paidIn(g, i, m.id)
    if (daysUntil(roundISO(g.start, g.freq, i), parseISO(today)) <= 0) dueSoFar += dueOf(g, m)
  }
  return { paid, dueSoFar, total: dueOf(g, m) * n }
}

// أدوار العضو (أرقامها من صفر)
export function turnsOf(g, memberId) {
  const out = []
  g.turns.forEach((t, i) => {
    const h = t.holders.find((x) => x.m === memberId)
    if (h) out.push({ i, f: h.f })
  })
  return out
}

// نسبة التقدّم (عدد الأدوار اللي قبضت)
export function progress(g) {
  const n = roundsCount(g)
  if (!n) return 0
  if (g.kind === 'member') {
    const done = Object.keys(g.paid || {}).length
    return Math.min(1, done / n)
  }
  const done = Object.keys(g.paidOut || {}).filter((k) => Number(k) < n).length
  return Math.min(1, done / n)
}

export function displayName(g) {
  return (g.name || '').trim() || 'جمعية بدون اسم'
}

// مشاكل تمنع الحفظ أو محتاجة تنبيه
export function orgIssues(g) {
  const issues = []
  if (!(g.amount > 0)) issues.push('اكتب قيمة القسط')
  if (g.members.length < 2) issues.push('أضف مشتركَين على الأقل')
  const halves = g.members.filter((m) => m.shares % 1).length
  if (halves % 2) issues.push('عدد أنصاف الأسهم يجب أن يكون زوجيًا (كل نصفين = دور واحد)')
  return issues
}
