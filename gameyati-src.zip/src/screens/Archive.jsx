import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { displayName, potOf, roundISO, roundsCount } from '../model/gam.js'
import { dateLong, money } from '../lib/format.js'

export default function Archive() {
  const { gams } = useApp()
  const nav = useNav()
  const list = gams.filter((g) => g.archived)
  return (
    <Screen title="الأرشيف">
      {list.length ? (
        <div className="member-list">
          {list.map((g) => {
            const n = roundsCount(g)
            return (
              <button key={g.id} type="button" className="member-row" onClick={() => nav.navigate({ name: g.kind === 'org' ? 'gam' : 'joined', id: g.id })}>
                <span className={`gam-ico ${g.kind === 'org' ? 'org' : 'mem'}`}>
                  <Icon name={g.kind === 'org' ? 'users' : 'wallet'} size={20} />
                </span>
                <span className="member-text">
                  <b>{displayName(g)}</b>
                  <small>
                    القبض {money(potOf(g), g.currency)}
                    {n ? ` · حتى ${dateLong(roundISO(g.start, g.freq, n - 1))}` : ''}
                  </small>
                </span>
                <Icon name="chev" size={18} className="muted-ico" />
              </button>
            )
          })}
        </div>
      ) : (
        <p className="empty-note">لا توجد جمعيات في الأرشيف.</p>
      )}
    </Screen>
  )
}
