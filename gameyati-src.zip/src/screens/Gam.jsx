import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp, useGam } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Screen, Segmented, Sheet } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import {
  currentRound,
  daysUntil,
  displayName,
  dueOf,
  isFinished,
  lateList,
  memberMap,
  memberStatus,
  memberTotals,
  paidIn,
  potOf,
  roundCollected,
  roundISO,
  roundsCount,
  turnNames,
  turnsOf,
} from '../model/gam.js'
import { dateDay, dateLong, dateShort, money, relDays, sharesLabel, waNumber, num } from '../lib/format.js'
import { openExternal, whatsappUrl, haptic, shareText } from '../lib/native.js'
import { payoutText, receiptText, reminderDue, reminderGroup, reminderOne, scheduleText } from '../lib/messages.js'
import { maybeAd, warmAd } from '../lib/ads.js'
import { exportPdf } from '../lib/report.js'

const STATUS = {
  paid: { label: 'دفع', cls: 'ok' },
  partial: { label: 'دفع جزء', cls: 'part' },
  late: { label: 'متأخر', cls: 'warn' },
  due: { label: 'اليوم', cls: 'due' },
  upcoming: { label: 'لم يحن', cls: 'mute' },
}

function PaymentSheet({ g, m, i, open, onClose, update }) {
  const { plus, settings, toast } = useApp()
  const due = m ? dueOf(g, m) : 0
  const paid = m ? paidIn(g, i, m.id) : 0
  const [amt, setAmt] = useState('')
  useEffect(() => {
    if (open) setAmt('')
  }, [open])
  if (!m) return null
  const brand = !(plus && settings.noBrand)
  const phone = waNumber(m.phone, g.currency)

  const setPaid = (value) => {
    update((x) => {
      const r = { ...(x.payments?.[i] || {}) }
      if (value > 0) r[m.id] = { amt: Math.min(value, due), at: Date.now() }
      else delete r[m.id]
      return { ...x, payments: { ...x.payments, [i]: r } }
    })
    haptic(12)
  }

  const wa = (text) => {
    openExternal(whatsappUrl(text, phone))
    setTimeout(() => maybeAd(plus), 1200)
  }

  return (
    <Sheet open={open} onClose={onClose} title={`${m.name} — الدور ${i + 1}`}>
      <div className="pay-info">
        <div>
          <small>القسط</small>
          <b>{money(due, g.currency)}</b>
        </div>
        <div>
          <small>المدفوع</small>
          <b className={paid >= due ? 'okc' : ''}>{money(paid, g.currency)}</b>
        </div>
        <div>
          <small>المتبقي</small>
          <b className={due - paid > 0 ? 'warnc' : ''}>{money(Math.max(0, due - paid), g.currency)}</b>
        </div>
      </div>
      {paid < due ? (
        <>
          <button
            type="button"
            className="btn btn-primary btn-block"
            onClick={() => {
              setPaid(due)
              toast(`تم تسجيل دفع ${m.name}`)
              onClose()
            }}
          >
            <Icon name="check" size={20} stroke={2.4} /> دفع القسط كاملًا
          </button>
          <form
            className="partial-row"
            onSubmit={(e) => {
              e.preventDefault()
              const v = Number(amt)
              if (!(v > 0)) return
              setPaid(paid + v)
              toast(`تم تسجيل ${money(Math.min(v, due - paid), g.currency)}`)
              onClose()
            }}
          >
            <input
              dir="ltr"
              inputMode="decimal"
              value={amt}
              maxLength={9}
              placeholder="مبلغ جزئي"
              aria-label="مبلغ جزئي"
              onChange={(e) => setAmt(e.target.value.replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/[^\d.]/g, ''))}
            />
            <button type="submit" className="btn btn-ghost btn-sm" disabled={!(Number(amt) > 0)}>
              تسجيل جزء
            </button>
          </form>
        </>
      ) : null}
      <div className="menu-list" style={{ marginTop: 14 }}>
        {paid > 0 ? (
          <button type="button" className="menu-item" onClick={() => wa(receiptText(g, m, i, paid, brand))}>
            <Icon name="receipt" /> إرسال إيصال على واتساب
          </button>
        ) : null}
        {paid < due ? (
          <button type="button" className="menu-item" onClick={() => wa(reminderDue(g, m, i))}>
            <Icon name="whatsapp" /> تذكير على واتساب
          </button>
        ) : null}
        {m.phone ? (
          <button type="button" className="menu-item" onClick={() => openExternal(`tel:${m.phone.replace(/[^\d+]/g, '')}`)}>
            <Icon name="phone" /> اتصال
          </button>
        ) : null}
        {paid > 0 ? (
          <button
            type="button"
            className="menu-item danger"
            onClick={() => {
              setPaid(0)
              toast('تم إلغاء الدفع')
              onClose()
            }}
          >
            <Icon name="close" /> إلغاء تسجيل الدفع
          </button>
        ) : null}
      </div>
    </Sheet>
  )
}

function MemberInfoSheet({ g, m, open, onClose, onRound }) {
  const { plus } = useApp()
  const nav = useNav()
  if (!m) return null
  const t = memberTotals(g, m)
  const mine = turnsOf(g, m.id)
  const late = lateList(g).find((x) => x.m.id === m.id)
  const phone = waNumber(m.phone, g.currency)
  return (
    <Sheet open={open} onClose={onClose} title={m.name}>
      <div className="pay-info">
        <div>
          <small>الأسهم</small>
          <b>{sharesLabel(m.shares)}</b>
        </div>
        <div>
          <small>دفع حتى الآن</small>
          <b>{money(t.paid, g.currency)}</b>
        </div>
        <div>
          <small>متأخر</small>
          <b className={late ? 'warnc' : 'okc'}>{late ? money(late.missing, g.currency) : 'لا شيء'}</b>
        </div>
      </div>
      <div className="mini-label">موعد القبض</div>
      <div className="chips" style={{ marginBottom: 14 }}>
        {mine.map(({ i, f }) => (
          <button
            key={i}
            type="button"
            className={`chip-btn ${g.paidOut?.[i] ? 'on' : ''}`}
            onClick={() => {
              onClose()
              onRound(i)
            }}
          >
            الدور {i + 1} · {dateShort(roundISO(g.start, g.freq, i))}
            {f === 0.5 ? ' (نصف)' : ''}
            {g.paidOut?.[i] ? ' ✓' : ''}
          </button>
        ))}
      </div>
      <div className="menu-list">
        {late ? (
          <button
            type="button"
            className="menu-item"
            onClick={() => {
              openExternal(whatsappUrl(reminderOne(g, m, late.rounds), phone))
              setTimeout(() => maybeAd(plus), 1200)
            }}
          >
            <Icon name="whatsapp" /> تذكير بالمتأخر على واتساب
          </button>
        ) : null}
        {m.phone ? (
          <button type="button" className="menu-item" onClick={() => openExternal(`tel:${m.phone.replace(/[^\d+]/g, '')}`)}>
            <Icon name="phone" /> اتصال <span className="muted" dir="ltr" style={{ marginInlineStart: 'auto' }}>{m.phone}</span>
          </button>
        ) : null}
        <button
          type="button"
          className="menu-item"
          onClick={() => {
            onClose()
            nav.navigate({ name: 'orgEdit', id: g.id })
          }}
        >
          <Icon name="edit" /> تعديل المشتركين
        </button>
      </div>
    </Sheet>
  )
}

function RoundView({ g, i, setI, update }) {
  const { plus, settings, toast } = useApp()
  const map = memberMap(g)
  const n = roundsCount(g)
  const iso = roundISO(g.start, g.freq, i)
  const d = daysUntil(iso)
  const pot = potOf(g)
  const collected = roundCollected(g, i)
  const done = !!g.paidOut?.[i]
  const [payFor, setPayFor] = useState(null)
  const [askPayout, setAskPayout] = useState(false)
  const chipsRef = useRef(null)
  const brand = !(plus && settings.noBrand)

  useEffect(() => {
    const el = chipsRef.current?.querySelector('.round-chip.sel')
    el?.scrollIntoView?.({ inline: 'center', block: 'nearest', behavior: 'smooth' })
  }, [i])

  const toggle = (m) => {
    const paid = paidIn(g, i, m.id)
    const due = dueOf(g, m)
    update((x) => {
      const r = { ...(x.payments?.[i] || {}) }
      if (paid >= due) delete r[m.id]
      else r[m.id] = { amt: due, at: Date.now() }
      return { ...x, payments: { ...x.payments, [i]: r } }
    })
    haptic(paid >= due ? 6 : 14)
  }

  const allPaid = () => {
    update((x) => {
      const r = { ...(x.payments?.[i] || {}) }
      for (const m of x.members) r[m.id] = { amt: dueOf(x, m), at: r[m.id]?.at || Date.now() }
      return { ...x, payments: { ...x.payments, [i]: r } }
    })
    haptic(16)
    toast('تم تسجيل دفع الجميع')
  }

  const setPayout = (on) => {
    update((x) => {
      const p = { ...(x.paidOut || {}) }
      if (on) p[i] = Date.now()
      else delete p[i]
      return { ...x, paidOut: p }
    })
    haptic(on ? 30 : 8)
  }

  const unpaid = g.members.filter((m) => paidIn(g, i, m.id) < dueOf(g, m) - 0.001)
  const remindAll = async () => {
    const list = unpaid.map((m) => ({ m, missing: dueOf(g, m) - paidIn(g, i, m.id) }))
    await shareText(reminderGroup(g, list), 'تذكير بالأقساط')
    setTimeout(() => maybeAd(plus), 800)
  }

  return (
    <>
      <div className="round-chips" ref={chipsRef}>
        {Array.from({ length: n }).map((_, k) => {
          const kd = daysUntil(roundISO(g.start, g.freq, k))
          return (
            <button
              key={k}
              type="button"
              className={`round-chip ${k === i ? 'sel' : ''} ${g.paidOut?.[k] ? 'done' : kd <= 0 ? 'past' : ''}`}
              onClick={() => setI(k)}
              aria-label={`الدور ${k + 1}`}
            >
              {k + 1}
            </button>
          )
        })}
      </div>

      <div className={`round-hero ${done ? 'done' : ''}`}>
        <div className="round-hero-top">
          <span>
            الدور {i + 1} من {n}
          </span>
          <span className="round-date">
            <Icon name="calendar" size={15} /> {dateDay(iso)} · {relDays(d)}
          </span>
        </div>
        <div className="round-who">
          <small>{done ? 'قبض' : 'يقبض'}</small>
          <b>{turnNames(g, g.turns[i], map) || '—'}</b>
          <span className="round-pot">{money(pot, g.currency)}</span>
        </div>
        <div className="bar light">
          <span style={{ width: `${pot ? Math.min(100, (collected / pot) * 100) : 0}%` }} />
        </div>
        <div className="round-hero-foot">
          <span>
            تم تحصيل {money(collected, g.currency)} من {money(pot, g.currency)}
          </span>
          <button type="button" className={`payout-btn ${done ? 'on' : ''}`} onClick={() => (done ? setPayout(false) : setAskPayout(true))}>
            {done ? (
              <>
                <Icon name="check" size={16} stroke={2.6} /> تم القبض
              </>
            ) : (
              'تسجيل القبض'
            )}
          </button>
        </div>
      </div>

      <div className="section-label">
        <span>المدفوعات ({g.members.length - unpaid.length}/{g.members.length})</span>
        {unpaid.length ? (
          <button type="button" className="link" onClick={allPaid}>
            الكل دفع
          </button>
        ) : null}
      </div>
      <div className="pay-list">
        {g.members.map((m, k) => {
          const st = memberStatus(g, i, m)
          const s = STATUS[st]
          const paid = paidIn(g, i, m.id)
          const due = dueOf(g, m)
          return (
            <div key={m.id} className={`pay-row ${st}`}>
              <button type="button" className={`pay-check ${st === 'paid' ? 'on' : ''}`} aria-label={st === 'paid' ? `إلغاء دفع ${m.name}` : `تسجيل دفع ${m.name}`} onClick={() => toggle(m)}>
                <Icon name="check" size={18} stroke={2.8} />
              </button>
              <button type="button" className="pay-main" onClick={() => setPayFor(m)}>
                <span className="avatar sm" style={{ '--h': (k * 47) % 360 }}>
                  {m.name.trim().slice(0, 1) || '؟'}
                </span>
                <span className="pay-text">
                  <b>{m.name}</b>
                  <small>
                    {st === 'partial' || (st === 'late' && paid > 0) ? `${num(paid)} من ${money(due, g.currency)}` : money(due, g.currency)}
                    {m.shares !== 1 ? ` · ${sharesLabel(m.shares)}` : ''}
                  </small>
                </span>
                <span className={`tag ${s.cls}`}>{s.label}</span>
              </button>
            </div>
          )
        })}
      </div>

      <div className="round-actions">
        {unpaid.length && d <= 1 ? (
          <button type="button" className="btn btn-soft" onClick={remindAll}>
            <Icon name="whatsapp" size={20} /> تذكير من لم يدفع
          </button>
        ) : null}
        {done ? (
          <button
            type="button"
            className="btn btn-soft"
            onClick={() => {
              openExternal(whatsappUrl(payoutText(g, i, brand)))
              setTimeout(() => maybeAd(plus), 1200)
            }}
          >
            <Icon name="whatsapp" size={20} /> تهنئة بالقبض
          </button>
        ) : null}
      </div>

      <PaymentSheet g={g} m={payFor} i={i} open={!!payFor} onClose={() => setPayFor(null)} update={update} />
      <Confirm
        open={askPayout}
        title={`تسجيل قبض الدور ${i + 1}؟`}
        text={
          collected < pot - 0.001
            ? `لم يكتمل التحصيل بعد (${money(collected, g.currency)} من ${money(pot, g.currency)}). هل سلّمت القبض لـ${turnNames(g, g.turns[i], map)}؟`
            : `هل سلّمت ${money(pot, g.currency)} لـ${turnNames(g, g.turns[i], map)}؟`
        }
        yes="نعم، تم القبض"
        onYes={() => {
          setAskPayout(false)
          setPayout(true)
          toast('مبروك! تم تسجيل القبض')
          if (i < n - 1 && daysUntil(roundISO(g.start, g.freq, i + 1)) <= 0) setTimeout(() => setI(i + 1), 500)
        }}
        onNo={() => setAskPayout(false)}
      />
    </>
  )
}

function ScheduleView({ g, onRound }) {
  const map = memberMap(g)
  const n = roundsCount(g)
  const cur = currentRound(g)
  return (
    <div className="sched-list">
      {Array.from({ length: n }).map((_, i) => {
        const done = !!g.paidOut?.[i]
        const iso = roundISO(g.start, g.freq, i)
        const col = roundCollected(g, i)
        const pot = potOf(g)
        const d = daysUntil(iso)
        return (
          <button key={i} type="button" className={`sched-row ${done ? 'done' : ''} ${!done && i === cur ? 'cur' : ''}`} onClick={() => onRound(i)}>
            <span className="turn-num">{i + 1}</span>
            <span className="sched-text">
              <b>{turnNames(g, g.turns[i], map) || '—'}</b>
              <small>
                {dateLong(iso)}
                {d <= 0 && !done ? ` · تحصيل \u2066${Math.round((col / (pot || 1)) * 100)}%\u2069` : ''}
              </small>
            </span>
            {done ? <span className="tag ok">قبض ✓</span> : i === cur && d <= 0 ? <span className="tag due">الحالي</span> : <span className="muted small">{relDays(d)}</span>}
          </button>
        )
      })}
    </div>
  )
}

function MembersView({ g, onMember }) {
  const late = new Map(lateList(g).map((x) => [x.m.id, x]))
  return (
    <div className="member-list">
      {g.members.map((m, k) => {
        const t = memberTotals(g, m)
        const mine = turnsOf(g, m.id)
        const l = late.get(m.id)
        return (
          <button key={m.id} type="button" className="member-row" onClick={() => onMember(m)}>
            <span className="avatar" style={{ '--h': (k * 47) % 360 }}>
              {m.name.trim().slice(0, 1) || '؟'}
            </span>
            <span className="member-text">
              <b>{m.name}</b>
              <small>
                {mine.length ? `يقبض: الدور ${mine.map((x) => x.i + 1).join(' و')}` : ''} · دفع {money(t.paid, g.currency)}
              </small>
            </span>
            {l ? <span className="tag warn">متأخر {num(l.missing)}</span> : <span className={`share-chip ${m.shares === 0.5 ? 'half' : m.shares > 1 ? 'multi' : ''}`}>{sharesLabel(m.shares)}</span>}
          </button>
        )
      })}
    </div>
  )
}

export default function Gam({ id, round }) {
  const [g, update] = useGam(id)
  const { plus, settings, toast, deleteGam, duplicateGam, canAddOrg } = useApp()
  const nav = useNav()
  const [tab, setTab] = useState('round')
  const [i, setI] = useState(() => (g ? (round ?? currentRound(g)) : 0))
  const [menu, setMenu] = useState(false)
  const [member, setMember] = useState(null)
  const [askDel, setAskDel] = useState(false)
  const late = useMemo(() => (g ? lateList(g) : []), [g])

  useEffect(() => warmAd(plus), [plus])

  if (!g) return null
  const n = roundsCount(g)
  const brand = !(plus && settings.noBrand)

  const goRound = (k) => {
    setI(k)
    setTab('round')
  }

  const doMenu = async (action) => {
    setMenu(false)
    if (action === 'edit') nav.navigate({ name: 'orgEdit', id })
    else if (action === 'order') nav.navigate({ name: 'order', id })
    else if (action === 'image') nav.navigate({ name: 'share', id })
    else if (action === 'text') {
      await shareText(scheduleText(g, brand), displayName(g))
      setTimeout(() => maybeAd(plus), 800)
    } else if (action === 'pdf') {
      if (!plus) nav.navigate({ name: 'paywall', reason: 'pdf' })
      else {
        const res = await exportPdf(g)
        if (!res?.ok && res?.reason !== 'cancel' && res?.reason !== 'dialog') toast('تعذّر إنشاء ملف PDF الآن')
      }
    } else if (action === 'dup') {
      if (!canAddOrg) nav.navigate({ name: 'paywall', reason: 'limit' })
      else {
        const nid = duplicateGam(id)
        if (nid) nav.replace({ name: 'orgEdit', id: nid })
      }
    } else if (action === 'archive') {
      update({ archived: !g.archived })
      toast(g.archived ? 'تمت الاستعادة من الأرشيف' : 'تم نقل الجمعية إلى الأرشيف')
      if (!g.archived) nav.back()
    } else if (action === 'delete') setAskDel(true)
  }

  return (
    <Screen
      title={displayName(g)}
      sub={`القسط ${money(g.amount, g.currency)} · القبض ${money(potOf(g), g.currency)}`}
      right={
        <button type="button" className="icon-btn" aria-label="خيارات" onClick={() => setMenu(true)}>
          <Icon name="more" />
        </button>
      }
      actions={
        <div className="dock">
          <button type="button" className="btn btn-primary" style={{ flex: 1 }} onClick={() => nav.navigate({ name: 'share', id })}>
            <Icon name="image" size={20} /> مشاركة الجدول
          </button>
          {late.length ? (
            <button
              type="button"
              className="btn btn-ghost"
              onClick={async () => {
                await shareText(reminderGroup(g, late), 'تذكير بالأقساط')
                setTimeout(() => maybeAd(plus), 800)
              }}
            >
              <Icon name="bell" size={20} /> {late.length} متأخر
            </button>
          ) : null}
        </div>
      }
    >
      {isFinished(g) ? <div className="done-banner">🎉 اكتملت الجمعية! كل الأدوار قبضت.</div> : null}
      <Segmented
        className="tabs"
        options={[
          { value: 'round', label: 'الدور' },
          { value: 'sched', label: 'الجدول' },
          { value: 'members', label: `المشتركون (${g.members.length})` },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div className="tab-body">
        {n === 0 ? (
          <p className="empty-note">لا توجد أدوار بعد. أضف المشتركين من «تعديل الجمعية».</p>
        ) : tab === 'round' ? (
          <RoundView g={g} i={Math.min(i, n - 1)} setI={setI} update={update} />
        ) : tab === 'sched' ? (
          <ScheduleView g={g} onRound={goRound} />
        ) : (
          <MembersView g={g} onMember={setMember} />
        )}
      </div>

      <MemberInfoSheet g={g} m={member} open={!!member} onClose={() => setMember(null)} onRound={goRound} />

      <Sheet open={menu} onClose={() => setMenu(false)} title={displayName(g)}>
        <div className="menu-list">
          <button type="button" className="menu-item" onClick={() => doMenu('edit')}>
            <Icon name="edit" /> تعديل الجمعية والمشتركين
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('order')}>
            <Icon name="dice" /> ترتيب الأدوار والقرعة
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('image')}>
            <Icon name="image" /> مشاركة الجدول كصورة
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('text')}>
            <Icon name="list" /> مشاركة الجدول كنص
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('pdf')}>
            <Icon name="download" /> تقرير PDF {!plus ? <span className="plus-badge sm" style={{ marginInlineStart: 'auto' }}>بلس</span> : null}
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('dup')}>
            <Icon name="copy" /> جمعية جديدة بنفس المشتركين
          </button>
          <button type="button" className="menu-item" onClick={() => doMenu('archive')}>
            <Icon name="archive" /> {g.archived ? 'استعادة من الأرشيف' : 'نقل إلى الأرشيف'}
          </button>
          <button type="button" className="menu-item danger" onClick={() => doMenu('delete')}>
            <Icon name="trash" /> حذف الجمعية
          </button>
        </div>
      </Sheet>
      <Confirm
        open={askDel}
        title="حذف الجمعية؟"
        text="سيتم حذف الجمعية وكل مدفوعاتها من جهازك نهائيًا."
        yes="حذف"
        danger
        onYes={() => {
          setAskDel(false)
          deleteGam(id)
          toast('تم الحذف')
          nav.back()
        }}
        onNo={() => setAskDel(false)}
      />
    </Screen>
  )
}

