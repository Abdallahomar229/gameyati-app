import { useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Icon } from '../components/Icons.jsx'
import { Sheet } from '../components/ui.jsx'
import {
  currentRound,
  daysUntil,
  displayName,
  isFinished,
  lateList,
  memberMap,
  potOf,
  progress,
  roundCollected,
  roundISO,
  roundsCount,
  turnNames,
} from '../model/gam.js'
import { dateShort, money, relDays } from '../lib/format.js'
import logo from '../assets/logo.png'

export function NewSheet({ open, onClose }) {
  const { canAddOrg } = useApp()
  const nav = useNav()
  const go = (route) => {
    onClose()
    nav.navigate(route)
  }
  return (
    <Sheet open={open} onClose={onClose} title="جمعية جديدة">
      <div className="kind-pick">
        <button type="button" className="kind-opt" onClick={() => go(canAddOrg ? { name: 'orgEdit' } : { name: 'paywall', reason: 'limit' })}>
          <span className="kind-ico org">
            <Icon name="users" size={26} />
          </span>
          <span className="kind-text">
            <b>أنا المنظِّم</b>
            <small>أجمع الأقساط وأرتّب الأدوار</small>
          </span>
          {!canAddOrg ? <span className="plus-badge sm">بلس</span> : <Icon name="chev" size={18} />}
        </button>
        <button type="button" className="kind-opt" onClick={() => go({ name: 'joinEdit' })}>
          <span className="kind-ico mem">
            <Icon name="wallet" size={26} />
          </span>
          <span className="kind-text">
            <b>أنا مشترك في جمعية</b>
            <small>أتابع أقساطي وموعد قبضي</small>
          </span>
          <Icon name="chev" size={18} />
        </button>
      </div>
    </Sheet>
  )
}

function OrgCard({ g }) {
  const nav = useNav()
  const n = roundsCount(g)
  const cur = currentRound(g)
  const map = memberMap(g)
  const finished = isFinished(g)
  const late = lateList(g)
  const collected = roundCollected(g, cur)
  const pot = potOf(g)
  const d = n ? daysUntil(roundISO(g.start, g.freq, cur)) : 0
  const next = !finished && n ? (g.paidOut?.[cur] && cur < n - 1 ? cur + 1 : cur) : null
  const nd = next != null ? daysUntil(roundISO(g.start, g.freq, next)) : 0
  return (
    <button type="button" className="gam-card" onClick={() => nav.navigate({ name: 'gam', id: g.id })}>
      <div className="gam-card-top">
        <span className="gam-ico org">
          <Icon name="users" size={20} />
        </span>
        <span className="gam-card-title">
          <b>{displayName(g)}</b>
          <small>
            {n ? `الدور ${cur + 1} من ${n}` : 'لا توجد أدوار بعد'} · القبض {money(pot, g.currency)}
          </small>
        </span>
        {late.length ? <span className="tag warn">{late.length} متأخر</span> : finished ? <span className="tag ok">اكتملت</span> : null}
      </div>
      {n ? (
        <>
          <div className="bar">
            <span style={{ width: `${Math.round(progress(g) * 100)}%` }} />
          </div>
          <div className="gam-card-foot">
            {finished ? (
              <span>اكتملت كل الأدوار. مبروك!</span>
            ) : (
              <>
                <span>
                  <Icon name="hand" size={15} /> {next === cur && d <= 0 ? 'يقبض الآن' : 'الدور القادم'}: <b>{turnNames(g, g.turns[next], map)}</b>
                </span>
                <span className="muted">{nd === 0 ? 'اليوم' : `${dateShort(roundISO(g.start, g.freq, next))} · ${relDays(nd)}`}</span>
              </>
            )}
          </div>
          {!finished && d <= 0 ? (
            <div className="gam-card-sub">
              تم تحصيل {money(collected, g.currency)} من {money(pot, g.currency)} في الدور الحالي
            </div>
          ) : null}
        </>
      ) : null}
    </button>
  )
}

function JoinedCard({ g }) {
  const nav = useNav()
  const n = roundsCount(g)
  const myIdx = g.myTurn - 1
  const d = daysUntil(roundISO(g.start, g.freq, myIdx))
  const cur = currentRound(g)
  const curPaid = !!g.paid?.[cur]
  const curD = daysUntil(roundISO(g.start, g.freq, cur))
  const finished = isFinished(g)
  return (
    <button type="button" className="gam-card" onClick={() => nav.navigate({ name: 'joined', id: g.id })}>
      <div className="gam-card-top">
        <span className="gam-ico mem">
          <Icon name="wallet" size={20} />
        </span>
        <span className="gam-card-title">
          <b>{displayName(g)}</b>
          <small>
            دوري {g.myTurn} من {n} · قسطي {money(g.amount, g.currency)}
          </small>
        </span>
        {finished ? <span className="tag ok">اكتملت</span> : !curPaid && curD < 0 ? <span className="tag warn">قسط متأخر</span> : null}
      </div>
      <div className="bar gold">
        <span style={{ width: `${Math.round(progress(g) * 100)}%` }} />
      </div>
      <div className="gam-card-foot">
        {g.received ? (
          <span>
            <Icon name="check" size={15} /> قبضت {money(potOf(g), g.currency)}
          </span>
        ) : (
          <>
            <span>
              <Icon name="hand" size={15} /> قبضي: <b>{money(potOf(g), g.currency)}</b>
            </span>
            <span className="muted">{d === 0 ? 'اليوم!' : d > 0 ? `${dateShort(roundISO(g.start, g.freq, myIdx))} · ${relDays(d)}` : 'حان موعده'}</span>
          </>
        )}
      </div>
    </button>
  )
}

export default function Home() {
  const { gams, plus } = useApp()
  const nav = useNav()
  const [newOpen, setNewOpen] = useState(false)
  const active = gams.filter((g) => !g.archived)
  const orgs = active.filter((g) => g.kind === 'org')
  const joined = active.filter((g) => g.kind === 'member')
  const archived = gams.filter((g) => g.archived)

  return (
    <div className="screen home">
      <header className="topbar">
        <div className="brand-row">
          <img className="logo" src={logo} alt="" />
          <span className="brand-name">جمعيتي</span>
        </div>
        {!plus ? (
          <button type="button" className="plus-pill" onClick={() => nav.navigate({ name: 'paywall', reason: 'home' })}>
            <Icon name="crown" size={15} stroke={2.2} /> بلس
          </button>
        ) : null}
        <button type="button" className="icon-btn" aria-label="الإعدادات" onClick={() => nav.navigate({ name: 'settings' })}>
          <Icon name="gear" />
        </button>
      </header>

      <main className="screen-body">
        {active.length === 0 ? (
          <section className="hero">
            <div className="hero-coins" aria-hidden="true">
              {Array.from({ length: 8 }).map((_, i) => (
                <span key={i} style={{ '--i': i }} />
              ))}
              <img src={logo} alt="" />
            </div>
            <h2>نظّم جمعيتك بدون لخبطة</h2>
            <p>سجّل المشتركين والأدوار، واعرف من دفع ومن تأخر، وأرسل الجدول والتذكير على واتساب في ثوانٍ.</p>
            <div className="hero-btns">
              <button type="button" className="btn btn-primary btn-block" onClick={() => nav.navigate({ name: 'orgEdit' })}>
                <Icon name="plus" size={20} stroke={2.2} /> أنشئ جمعية جديدة
              </button>
              <button type="button" className="btn btn-line btn-block" onClick={() => nav.navigate({ name: 'joinEdit' })}>
                <Icon name="wallet" size={20} /> أنا مشترك في جمعية
              </button>
            </div>
            <div className="hero-feats">
              <span>
                <Icon name="check" size={15} stroke={2.6} /> نصف سهم وقرعة
              </span>
              <span>
                <Icon name="check" size={15} stroke={2.6} /> تذكير بالمواعيد
              </span>
              <span>
                <Icon name="check" size={15} stroke={2.6} /> بياناتك على جهازك
              </span>
            </div>
            {archived.length ? (
              <button type="button" className="link archive-link light" onClick={() => nav.navigate({ name: 'archive' })}>
                <Icon name="archive" size={17} /> الأرشيف ({archived.length})
              </button>
            ) : null}
          </section>
        ) : (
          <>
            {orgs.length ? (
              <>
                <div className="section-label">
                  <span>جمعيات أنظّمها ({orgs.length})</span>
                </div>
                <div className="gam-list">
                  {orgs.map((g) => (
                    <OrgCard key={g.id} g={g} />
                  ))}
                </div>
              </>
            ) : null}
            {joined.length ? (
              <>
                <div className="section-label">
                  <span>جمعيات أنا مشترك فيها ({joined.length})</span>
                </div>
                <div className="gam-list">
                  {joined.map((g) => (
                    <JoinedCard key={g.id} g={g} />
                  ))}
                </div>
              </>
            ) : null}
            <button type="button" className="new-card" onClick={() => setNewOpen(true)}>
              <span className="plus-circle">
                <Icon name="plus" size={22} stroke={2.2} />
              </span>
              جمعية جديدة
            </button>
            {archived.length ? (
              <button type="button" className="link archive-link" onClick={() => nav.navigate({ name: 'archive' })}>
                <Icon name="archive" size={17} /> الأرشيف ({archived.length})
              </button>
            ) : null}
          </>
        )}
      </main>

      <NewSheet open={newOpen} onClose={() => setNewOpen(false)} />
    </div>
  )
}
