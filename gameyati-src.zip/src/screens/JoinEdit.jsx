import { useEffect, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Field, Screen, Segmented } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { CURRENCIES, FREQS, blankJoined, normalize, potOf, roundISO } from '../model/gam.js'
import { dateLong, money } from '../lib/format.js'

function Stepper({ label, value, min, max, onChange, hint }) {
  return (
    <div className="field">
      <label>{label}</label>
      <div className="stepper">
        <button type="button" className="icon-btn" aria-label="زيادة" disabled={value >= max} onClick={() => onChange(Math.min(max, value + 1))}>
          <Icon name="plus" size={20} stroke={2.2} />
        </button>
        <input
          dir="ltr"
          inputMode="numeric"
          value={value}
          aria-label={label}
          onChange={(e) => {
            const v = Number(e.target.value.replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/\D/g, ''))
            if (Number.isFinite(v)) onChange(Math.min(max, Math.max(min, v || min)))
          }}
        />
        <button type="button" className="icon-btn" aria-label="نقص" disabled={value <= min} onClick={() => onChange(Math.max(min, value - 1))}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true">
            <path d="M5 12h14" />
          </svg>
        </button>
      </div>
      {hint ? <span className="field-hint">{hint}</span> : null}
    </div>
  )
}

export default function JoinEdit({ id }) {
  const { gams, addGam, updateGam, currency, setSetting, toast } = useApp()
  const nav = useNav()
  const existing = id ? gams.find((g) => g.id === id) : null
  const [g, setG] = useState(() => (existing ? normalize(JSON.parse(JSON.stringify(existing))) : blankJoined(currency)))
  const [dirty, setDirty] = useState(false)
  const set = (patch) => {
    setDirty(true)
    setG((x) => ({ ...x, ...patch }))
  }

  useEffect(() => {
    nav.setGuard(dirty ? () => true : null)
    return () => nav.setGuard(null)
  }, [dirty, nav])

  const ok = Number(g.amount) > 0 && g.rounds >= 2
  const save = () => {
    if (!(Number(g.amount) > 0)) return toast('اكتب قيمة قسطك')
    if (g.rounds < 2) return toast('عدد الأدوار يجب أن يكون 2 أو أكثر')
    const final = { ...g, name: g.name.trim(), organizer: g.organizer.trim(), amount: Number(g.amount), myTurn: Math.min(g.myTurn, g.rounds) }
    setSetting('currency', g.currency)
    nav.setGuard(null)
    if (existing) {
      updateGam(existing.id, final)
      toast('تم حفظ التعديلات')
      nav.back()
    } else {
      addGam(final)
      nav.replace({ name: 'joined', id: final.id })
    }
    return undefined
  }

  const turn = Math.min(g.myTurn, g.rounds)
  return (
    <Screen
      title={existing ? 'تعديل الجمعية' : 'جمعية أنا مشترك فيها'}
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={save}>
          {existing ? 'حفظ التعديلات' : 'حفظ'}
        </button>
      }
    >
      <Field label="اسم الجمعية" value={g.name} maxLength={40} placeholder="مثلًا: جمعية الشغل" onChange={(v) => set({ name: v })} />
      <Field label="اسم المنظِّم (اختياري)" value={g.organizer} maxLength={40} placeholder="مثلًا: أم محمد" onChange={(v) => set({ organizer: v })} />
      <div className="grid2 amount-row">
        <Field
          label="قسطي في كل دور"
          value={g.amount === 0 ? '' : String(g.amount)}
          dir="ltr"
          inputMode="decimal"
          maxLength={9}
          placeholder="1000"
          onChange={(v) => set({ amount: v.replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/[^\d.]/g, '') })}
        />
        <Field label="العملة">
          <select value={g.currency} onChange={(e) => set({ currency: e.target.value })} aria-label="العملة">
            {CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label} ({c.short})
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="field">
        <label>موعد الدفع</label>
        <Segmented options={FREQS.map((x) => ({ value: x.value, label: x.label }))} value={g.freq} onChange={(v) => set({ freq: v })} />
      </div>
      <Field label="تاريخ أول دور" type="date" dir="ltr" value={g.start} onChange={(v) => v && set({ start: v })} />
      <div className="grid2">
        <Stepper label="عدد الأدوار" value={g.rounds} min={2} max={120} onChange={(v) => set({ rounds: v, myTurn: Math.min(g.myTurn, v) })} />
        <Stepper label="دوري رقم" value={turn} min={1} max={g.rounds} onChange={(v) => set({ myTurn: v })} />
      </div>
      {ok ? (
        <div className="join-sum">
          <Icon name="hand" size={22} />
          <p>
            ستقبض <b>{money(potOf({ ...g, amount: Number(g.amount), kind: 'member' }), g.currency)}</b> يوم <b>{dateLong(roundISO(g.start, g.freq, turn - 1))}</b>
            <br />
            <small>وستدفع {money(Number(g.amount), g.currency)} في كل دور حتى {dateLong(roundISO(g.start, g.freq, g.rounds - 1))}.</small>
          </p>
        </div>
      ) : null}
      <Confirm
        open={nav.exitAsk}
        title="الخروج بدون حفظ؟"
        text="لديك تعديلات لم تُحفظ."
        yes="خروج بدون حفظ"
        no="متابعة التعديل"
        danger
        onYes={nav.confirmExit}
        onNo={nav.cancelExit}
      />
    </Screen>
  )
}
