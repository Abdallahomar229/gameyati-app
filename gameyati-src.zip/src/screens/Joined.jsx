import { useState } from 'react'
import { useApp, useGam } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Screen, Sheet } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { currentRound, daysUntil, displayName, isFinished, potOf, roundISO } from '../model/gam.js'
import { dateDay, dateLong, money, relDays } from '../lib/format.js'
import { haptic, shareText } from '../lib/native.js'

export default function Joined({ id }) {
  const [g, update] = useGam(id)
  const { toast, deleteGam } = useApp()
  const nav = useNav()
  const [menu, setMenu] = useState(false)
  const [askDel, setAskDel] = useState(false)
  if (!g) return null

  const n = g.rounds
  const my = g.myTurn - 1
  const myIso = roundISO(g.start, g.freq, my)
  const d = daysUntil(myIso)
  const cur = currentRound(g)
  const paidCount = Object.keys(g.paid || {}).filter((k) => Number(k) < n).length
  const pot = potOf(g)
  const lateCount = Array.from({ length: n }).filter((_, i) => !g.paid?.[i] && daysUntil(roundISO(g.start, g.freq, i)) < 0).length

  const togglePaid = (i) => {
    update((x) => {
      const p = { ...(x.paid || {}) }
      if (p[i]) delete p[i]
      else p[i] = Date.now()
      return { ...x, paid: p }
    })
    haptic(g.paid?.[i] ? 6 : 14)
  }

  const setReceived = (on) => {
    update({ received: on ? Date.now() : 0 })
    haptic(on ? 30 : 8)
    if (on) toast('مبروك! تم تسجيل القبض')
  }

  const shareMine = async () => {
    setMenu(false)
    await shareText(
      `دوري في جمعية «${displayName(g)}»: رقم ${g.myTurn} من ${n}\nموعد القبض: ${dateLong(myIso)}\nالقبض: ${money(pot, g.currency)}`,
      displayName(g),
    )
  }

  return (
    <Screen
      title={displayName(g)}
      sub={g.organizer ? `المنظِّم: ${g.organizer}` : `قسطي ${money(g.amount, g.currency)}`}
      right={
        <button type="button" className="icon-btn" aria-label="خيارات" onClick={() => setMenu(true)}>
          <Icon name="more" />
        </button>
      }
    >
      {isFinished(g) ? <div className="done-banner">🎉 اكتملت الجمعية!</div> : null}
      <div className={`round-hero mine ${g.received ? 'done' : ''}`}>
        <div className="round-hero-top">
          <span>
            دوري رقم {g.myTurn} من {n}
          </span>
          <span className="round-date">
            <Icon name="calendar" size={15} /> {dateDay(myIso)}
          </span>
        </div>
        <div className="round-who">
          <small>{g.received ? 'قبضت' : d > 0 ? `قبضي ${relDays(d)}` : d === 0 ? 'قبضي اليوم!' : 'حان موعد قبضي'}</small>
          <b className="big-money">{money(pot, g.currency)}</b>
        </div>
        <div className="bar light">
          <span style={{ width: `${Math.round((paidCount / n) * 100)}%` }} />
        </div>
        <div className="round-hero-foot">
          <span>
            دفعت {paidCount} من {n} أقساط ({money(paidCount * g.amount, g.currency)})
          </span>
          {d <= 0 || g.received ? (
            <button type="button" className={`payout-btn ${g.received ? 'on' : ''}`} onClick={() => setReceived(!g.received)}>
              {g.received ? (
                <>
                  <Icon name="check" size={16} stroke={2.6} /> قبضت
                </>
              ) : (
                'استلمت القبض'
              )}
            </button>
          ) : null}
        </div>
      </div>

      <div className="section-label">
        <span>أقساطي</span>
        {lateCount ? <span className="tag warn">{lateCount} متأخر</span> : null}
      </div>
      <div className="pay-list">
        {Array.from({ length: n }).map((_, i) => {
          const iso = roundISO(g.start, g.freq, i)
          const di = daysUntil(iso)
          const paid = !!g.paid?.[i]
          const st = paid ? 'paid' : di < 0 ? 'late' : di === 0 ? 'due' : 'upcoming'
          return (
            <div key={i} className={`pay-row ${st} ${i === my ? 'my-turn' : ''}`}>
              <button type="button" className={`pay-check ${paid ? 'on' : ''}`} aria-label={paid ? `إلغاء دفع الدور ${i + 1}` : `دفعت قسط الدور ${i + 1}`} onClick={() => togglePaid(i)}>
                <Icon name="check" size={18} stroke={2.8} />
              </button>
              <div className="pay-main static">
                <span className="turn-num sm">{i + 1}</span>
                <span className="pay-text">
                  <b>
                    {dateLong(iso)}
                    {i === my ? <span className="tag gold">دوري</span> : null}
                  </b>
                  <small>
                    {money(g.amount, g.currency)}
                    {i === cur && !paid ? ' · الدور الحالي' : ''}
                  </small>
                </span>
                <span className={`tag ${paid ? 'ok' : st === 'late' ? 'warn' : st === 'due' ? 'due' : 'mute'}`}>{paid ? 'دفعت' : st === 'late' ? 'متأخر' : st === 'due' ? 'اليوم' : relDays(di)}</span>
              </div>
            </div>
          )
        })}
      </div>

      <Sheet open={menu} onClose={() => setMenu(false)} title={displayName(g)}>
        <div className="menu-list">
          <button
            type="button"
            className="menu-item"
            onClick={() => {
              setMenu(false)
              nav.navigate({ name: 'joinEdit', id })
            }}
          >
            <Icon name="edit" /> تعديل البيانات
          </button>
          <button type="button" className="menu-item" onClick={shareMine}>
            <Icon name="share" /> مشاركة موعد دوري
          </button>
          <button
            type="button"
            className="menu-item"
            onClick={() => {
              setMenu(false)
              update({ archived: !g.archived })
              toast(g.archived ? 'تمت الاستعادة من الأرشيف' : 'تم نقل الجمعية إلى الأرشيف')
              if (!g.archived) nav.back()
            }}
          >
            <Icon name="archive" /> {g.archived ? 'استعادة من الأرشيف' : 'نقل إلى الأرشيف'}
          </button>
          <button
            type="button"
            className="menu-item danger"
            onClick={() => {
              setMenu(false)
              setAskDel(true)
            }}
          >
            <Icon name="trash" /> حذف
          </button>
        </div>
      </Sheet>
      <Confirm
        open={askDel}
        title="حذف الجمعية؟"
        text="سيتم حذفها من جهازك نهائيًا."
        yes="حذف"
        danger
        onYes={() => {
          setAskDel(false)
          deleteGam(id)
          toast('تم الحذف')
          nav.back()
        }}
        onNo={() => setAskDel(false)}
      />
    </Screen>
  )
}
