import { useEffect, useRef, useState } from 'react'
import { useApp, useGam } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Screen } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { memberMap, openHalfTurns, roundISO, shuffleTurns } from '../model/gam.js'
import { dateLong } from '../lib/format.js'
import { haptic } from '../lib/native.js'

export default function Order({ id, fresh }) {
  const [g, update] = useGam(id)
  const { toast } = useApp()
  const nav = useNav()
  const [turns, setTurns] = useState(() => g?.turns || [])
  const [drawing, setDrawing] = useState(false)
  const [picked, setPicked] = useState(null) // { t, m } نص سهم متعلّم للتبديل
  const [dirty, setDirty] = useState(!!fresh)
  const [askDraw, setAskDraw] = useState(false)
  const [touched, setTouched] = useState(false) // اتحرك يدوي
  const timers = useRef([])

  useEffect(() => () => timers.current.forEach(clearTimeout), [])
  useEffect(() => {
    nav.setGuard(dirty && !fresh ? () => true : null)
    return () => nav.setGuard(null)
  }, [dirty, fresh, nav])

  if (!g) return null
  const map = memberMap(g)
  const locked = (i) => !!g.paidOut?.[i]
  const hasLocked = turns.some((_, i) => locked(i))

  const move = (i, dir) => {
    const j = i + dir
    if (j < 0 || j >= turns.length || locked(i) || locked(j)) return
    const a = turns.slice()
    ;[a[i], a[j]] = [a[j], a[i]]
    setTurns(a)
    setDirty(true)
    setTouched(true)
    haptic(8)
  }

  // قرعة على الأدوار اللي لسه متقبضتش
  const runDraw = () => {
    setAskDraw(false)
    if (drawing) return
    const free = turns.map((t, i) => (locked(i) ? null : i)).filter((i) => i != null)
    if (free.length < 2) return
    setDrawing(true)
    setPicked(null)
    const steps = 14
    let cur = turns
    for (let s = 0; s <= steps; s++) {
      const delay = 40 + s * s * 4.5 + s * 30
      timers.current.push(
        setTimeout(() => {
          const pool = shuffleTurns(free.map((i) => cur[i]))
          const next = cur.slice()
          free.forEach((i, k) => (next[i] = pool[k]))
          cur = next
          setTurns(next)
          haptic(s === steps ? 30 : 6)
          if (s === steps) {
            setDrawing(false)
            setDirty(true)
            setTouched(true)
            toast('تمت القرعة!')
          }
        }, delay),
      )
    }
  }

  // تبديل شركاء نص السهم بين دورين
  const pickHalf = (ti, mid) => {
    if (drawing) return
    if (!picked) {
      setPicked({ t: ti, m: mid })
      return
    }
    if (picked.t === ti) {
      setPicked(null)
      return
    }
    const a = turns.map((t) => ({ ...t, holders: t.holders.map((h) => ({ ...h })) }))
    const h1 = a[picked.t].holders.find((h) => h.m === picked.m)
    const h2 = a[ti].holders.find((h) => h.m === mid)
    if (h1 && h2 && !a[ti].holders.some((h) => h.m === picked.m) && !a[picked.t].holders.some((h) => h.m === mid)) {
      h1.m = mid
      h2.m = picked.m
      setTurns(a)
      setDirty(true)
      setTouched(true)
      haptic(10)
    }
    setPicked(null)
  }

  const save = () => {
    update({ turns })
    nav.setGuard(null)
    if (fresh) nav.replace({ name: 'gam', id })
    else {
      toast('تم حفظ الترتيب')
      nav.back()
    }
  }

  const open = openHalfTurns({ ...g, turns })
  return (
    <Screen
      title="ترتيب الأدوار"
      sub={g.name}
      actions={
        <div className="order-actions">
          <button type="button" className="btn btn-gold" disabled={drawing || turns.length < 2} onClick={() => (touched || hasLocked ? setAskDraw(true) : runDraw())}>
            <Icon name="dice" size={20} /> قرعة
          </button>
          <button type="button" className="btn btn-primary" style={{ flex: 1 }} disabled={drawing} onClick={save}>
            {fresh ? 'حفظ وابدأ الجمعية' : 'حفظ الترتيب'}
          </button>
        </div>
      }
    >
      <p className="tip-line">
        رتّب الأدوار بأزرار ↑↓، أو أجرِ <b>قرعة</b> عشوائية أمام الجميع.
        {turns.some((t) => t.holders.length > 1) ? ' لتبديل شريك نصف السهم: اضغط على اسمه ثم على اسم آخر.' : ''}
      </p>
      {open.length ? <p className="warn-line">يوجد نصف سهم بدون شريك. أضف نصف سهم آخر من تعديل الجمعية.</p> : null}
      <ol className={`turn-list ${drawing ? 'drawing' : ''}`}>
        {turns.map((t, i) => (
          <li key={t.id} className={`turn-row ${locked(i) ? 'locked' : ''}`}>
            <span className="turn-num">{i + 1}</span>
            <span className="turn-text">
              <span className="turn-names">
                {t.holders.length > 1 || t.holders[0]?.f === 0.5
                  ? t.holders.map((h) => (
                      <button
                        key={h.m}
                        type="button"
                        className={`half-chip ${picked?.t === i && picked?.m === h.m ? 'on' : ''}`}
                        disabled={locked(i)}
                        onClick={() => pickHalf(i, h.m)}
                      >
                        {map.get(h.m)?.name || '—'} <small>½</small>
                      </button>
                    ))
                  : map.get(t.holders[0]?.m)?.name || '—'}
              </span>
              <small>{locked(i) ? 'تم القبض' : dateLong(roundISO(g.start, g.freq, i))}</small>
            </span>
            {locked(i) ? (
              <Icon name="lock" size={18} className="muted-ico" />
            ) : (
              <span className="turn-move">
                <button type="button" className="icon-btn sm" aria-label="لأعلى" disabled={i === 0 || locked(i - 1) || drawing} onClick={() => move(i, -1)}>
                  <Icon name="arrowUp" size={18} />
                </button>
                <button type="button" className="icon-btn sm" aria-label="لأسفل" disabled={i === turns.length - 1 || locked(i + 1) || drawing} onClick={() => move(i, 1)}>
                  <Icon name="arrowDown" size={18} />
                </button>
              </span>
            )}
          </li>
        ))}
      </ol>
      <Confirm
        open={askDraw}
        title="إجراء قرعة جديدة؟"
        text={hasLocked ? 'سيتغير ترتيب الأدوار التي لم تُقبض بعد فقط.' : 'سيتغير الترتيب الحالي بالكامل.'}
        yes="ابدأ القرعة"
        onYes={runDraw}
        onNo={() => setAskDraw(false)}
      />
      <Confirm
        open={nav.exitAsk}
        title="الخروج بدون حفظ؟"
        text="لم يتم حفظ الترتيب الجديد."
        yes="خروج بدون حفظ"
        no="متابعة"
        danger
        onYes={nav.confirmExit}
        onNo={nav.cancelExit}
      />
    </Screen>
  )
}
