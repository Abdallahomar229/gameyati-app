import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Field, Screen, Segmented, Sheet } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { CURRENCIES, FREQS, SHARE_OPTIONS, blankOrg, normalize, orgIssues, potOf, roundISO, syncTurns, totalShares, uid } from '../model/gam.js'
import { dateLong, durationWord, money, roundsWord, sharesLabel } from '../lib/format.js'

function MemberSheet({ open, member, onSave, onDelete, onClose, hasPayments }) {
  const [m, setM] = useState(member)
  const [askDel, setAskDel] = useState(false)
  useEffect(() => {
    if (open) setM(member)
  }, [open, member])
  if (!m) return null
  const isNew = !member?.name
  return (
    <>
      <Sheet
        open={open}
        onClose={onClose}
        title={isNew ? 'مشترك جديد' : 'بيانات المشترك'}
        footer={
          <button type="button" className="btn btn-primary btn-block" disabled={!m.name.trim()} onClick={() => onSave({ ...m, name: m.name.trim(), phone: m.phone.trim() })}>
            {isNew ? 'إضافة' : 'حفظ'}
          </button>
        }
      >
        <Field label="الاسم" value={m.name} maxLength={40} placeholder="مثلًا: أم أحمد" onChange={(v) => setM((x) => ({ ...x, name: v }))} />
        <Field
          label="رقم الموبايل (اختياري — لإرسال التذكير على واتساب)"
          value={m.phone}
          type="tel"
          dir="ltr"
          inputMode="tel"
          maxLength={20}
          placeholder="01xxxxxxxxx"
          onChange={(v) => setM((x) => ({ ...x, phone: v }))}
        />
        <div className="field">
          <label>عدد الأسهم</label>
          <Segmented options={SHARE_OPTIONS.map((o) => ({ value: o.value, label: o.label }))} value={m.shares} onChange={(v) => setM((x) => ({ ...x, shares: v }))} />
          <span className="field-hint">
            {m.shares === 0.5 ? 'نصف سهم: يدفع نصف القسط ويقبض نصف المبلغ مع شريك في نفس الدور.' : m.shares > 1 ? `سيأخذ ${sharesLabel(m.shares)} = ${m.shares} أدوار للقبض.` : 'سهم كامل = دور واحد للقبض.'}
          </span>
        </div>
        {!isNew ? (
          <button type="button" className="link danger-link" onClick={() => setAskDel(true)}>
            <Icon name="trash" size={17} /> حذف المشترك
          </button>
        ) : null}
      </Sheet>
      <Confirm
        open={askDel}
        title={`حذف ${m.name}؟`}
        text={hasPayments ? 'هذا المشترك له مدفوعات مسجّلة، وسيتم حذفها معه.' : 'سيتم حذفه من الجمعية وإعادة توزيع الأدوار.'}
        yes="حذف"
        danger
        onYes={() => {
          setAskDel(false)
          onDelete(m.id)
        }}
        onNo={() => setAskDel(false)}
      />
    </>
  )
}

export default function OrgEdit({ id }) {
  const { gams, addGam, updateGam, currency, setSetting, toast } = useApp()
  const nav = useNav()
  const existing = id ? gams.find((g) => g.id === id) : null
  const [g, setG] = useState(() => (existing ? normalize(JSON.parse(JSON.stringify(existing))) : blankOrg(currency)))
  const [dirty, setDirty] = useState(false)
  const [sheet, setSheet] = useState(null) // عضو بيتعدّل
  const [quick, setQuick] = useState('')
  const [tried, setTried] = useState(false)
  const quickRef = useRef(null)

  const set = (patch) => {
    setDirty(true)
    setG((x) => ({ ...x, ...patch }))
  }

  // حارس الرجوع لو فيه تعديلات
  useEffect(() => {
    nav.setGuard(dirty ? () => true : null)
    return () => nav.setGuard(null)
  }, [dirty, nav])

  const synced = useMemo(() => syncTurns(g), [g])
  const issues = orgIssues(g)
  const n = synced.turns.length
  const pot = potOf(synced)

  const addQuick = () => {
    const name = quick.trim()
    if (!name) return
    set({ members: [...g.members, { id: uid('m'), name, phone: '', shares: 1 }] })
    setQuick('')
    quickRef.current?.focus()
  }

  const saveMember = (m) => {
    const exists = g.members.some((x) => x.id === m.id)
    set({ members: exists ? g.members.map((x) => (x.id === m.id ? m : x)) : [...g.members, m] })
    setSheet(null)
  }

  const deleteMember = (mid) => {
    const payments = {}
    for (const [k, v] of Object.entries(g.payments || {})) {
      const { [mid]: _, ...rest } = v || {}
      payments[k] = rest
    }
    set({ members: g.members.filter((x) => x.id !== mid), payments })
    setSheet(null)
  }

  const hasPayments = (mid) => Object.values(g.payments || {}).some((r) => r?.[mid])

  const save = () => {
    setTried(true)
    if (issues.length) {
      toast(issues[0])
      return
    }
    const final = { ...synced, name: g.name.trim(), amount: Number(g.amount) }
    setSetting('currency', g.currency)
    nav.setGuard(null)
    if (existing) {
      updateGam(existing.id, final)
      toast('تم حفظ التعديلات')
      nav.back()
    } else {
      addGam(final)
      nav.replace({ name: 'order', id: final.id, fresh: true })
    }
  }

  return (
    <Screen
      title={existing ? 'تعديل الجمعية' : 'جمعية جديدة'}
      actions={
        <button type="button" className="btn btn-primary btn-block" onClick={save}>
          {existing ? 'حفظ التعديلات' : 'التالي: ترتيب الأدوار'}
          {!existing ? <Icon name="chev" size={18} /> : null}
        </button>
      }
    >
      <Field label="اسم الجمعية" value={g.name} maxLength={40} placeholder="مثلًا: جمعية العيلة" onChange={(v) => set({ name: v })} />
      <div className="grid2 amount-row">
        <Field
          label="قسط السهم"
          value={g.amount === 0 ? '' : String(g.amount)}
          type="text"
          dir="ltr"
          inputMode="decimal"
          maxLength={9}
          placeholder="1000"
          onChange={(v) => set({ amount: v.replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x660)).replace(/[^\d.]/g, '') })}
          className={tried && !(Number(g.amount) > 0) ? 'bad' : ''}
        />
        <Field label="العملة">
          <select value={g.currency} onChange={(e) => set({ currency: e.target.value })} aria-label="العملة">
            {CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label} ({c.short})
              </option>
            ))}
          </select>
        </Field>
      </div>
      <div className="field">
        <label>موعد الدفع والقبض</label>
        <Segmented options={FREQS.map((x) => ({ value: x.value, label: x.label }))} value={g.freq} onChange={(v) => set({ freq: v })} />
      </div>
      <Field label="تاريخ أول دور" type="date" dir="ltr" value={g.start} onChange={(v) => v && set({ start: v })} />

      <div className="section-label">
        <span>المشتركون ({g.members.length})</span>
        <span>{totalShares(g) ? `${totalShares(g)} سهم` : ''}</span>
      </div>
      <form
        className="quick-add"
        onSubmit={(e) => {
          e.preventDefault()
          addQuick()
        }}
      >
        <input ref={quickRef} value={quick} maxLength={40} placeholder="اكتب اسم المشترك واضغط إضافة" onChange={(e) => setQuick(e.target.value)} aria-label="اسم المشترك" />
        <button type="submit" className="btn btn-soft btn-sm" disabled={!quick.trim()}>
          <Icon name="plus" size={18} stroke={2.2} /> إضافة
        </button>
      </form>
      {g.members.length ? (
        <div className="member-list">
          {g.members.map((m, i) => (
            <button key={m.id} type="button" className="member-row" onClick={() => setSheet(m)}>
              <span className="avatar" style={{ '--h': (i * 47) % 360 }}>
                {m.name.trim().slice(0, 1) || '؟'}
              </span>
              <span className="member-text">
                <b>{m.name}</b>
                <small dir={m.phone ? 'ltr' : undefined}>{m.phone || 'بدون رقم'}</small>
              </span>
              <span className={`share-chip ${m.shares === 0.5 ? 'half' : m.shares > 1 ? 'multi' : ''}`}>{sharesLabel(m.shares)}</span>
              <Icon name="edit" size={17} className="muted-ico" />
            </button>
          ))}
        </div>
      ) : (
        <p className="empty-note">أضف أسماء المشتركين. يمكنك تعديل عدد الأسهم ورقم الموبايل بالضغط على الاسم.</p>
      )}
      <button type="button" className="link add-detail" onClick={() => setSheet({ id: uid('m'), name: '', phone: '', shares: 1 })}>
        <Icon name="plus" size={17} /> إضافة مشترك برقم موبايل أو نصف سهم
      </button>

      <div className="summary-box">
        <div>
          <small>عدد الأدوار</small>
          <b>{n || '—'}</b>
        </div>
        <div>
          <small>القبض في كل دور</small>
          <b>{pot ? money(pot, g.currency) : '—'}</b>
        </div>
        <div>
          <small>المدة</small>
          <b>{n ? durationWord(n, g.freq) : '—'}</b>
        </div>
      </div>
      {n ? (
        <p className="field-hint center">
          {roundsWord(n)} من {dateLong(g.start)} إلى {dateLong(roundISO(g.start, g.freq, n - 1))}
        </p>
      ) : null}
      {tried && issues.length ? (
        <ul className="issues">
          {issues.map((x) => (
            <li key={x}>{x}</li>
          ))}
        </ul>
      ) : null}

      <MemberSheet open={!!sheet} member={sheet} hasPayments={sheet ? hasPayments(sheet.id) : false} onSave={saveMember} onDelete={deleteMember} onClose={() => setSheet(null)} />
      <Confirm
        open={nav.exitAsk}
        title="الخروج بدون حفظ؟"
        text="لديك تعديلات لم تُحفظ."
        yes="خروج بدون حفظ"
        no="متابعة التعديل"
        danger
        onYes={nav.confirmExit}
        onNo={nav.cancelExit}
      />
    </Screen>
  )
}
