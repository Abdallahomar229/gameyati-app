import { useEffect, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { getOfferings, purchase, restore, PLANS } from '../lib/billing.js'
import { nativePlatform } from '../lib/native.js'
import logo from '../assets/logo.png'

// شروط الاستخدام القياسية (أبل بتطلب لينك ليها جنب أي اشتراك بيتجدد)
const TERMS_URL = 'https://www.apple.com/legal/internet-services/itunes/dev/stdeula/'

const BENEFITS = [
  'نظّم عدد غير محدود من الجمعيات في نفس الوقت',
  'تقرير PDF كامل لكل جمعية (الأدوار والمدفوعات)',
  'صورة الجدول والرسائل بدون علامة التطبيق',
  'بدون إعلانات نهائيًا',
]

const HEAD = {
  limit: 'النسخة المجانية تتيح تنظيم جمعية واحدة',
  pdf: 'تقرير PDF ضمن «جمعيتي بلس»',
  brand: 'شارك الجدول بدون علامة التطبيق',
}

export default function Paywall({ reason }) {
  const { plus, entitled, reviewPlus, toast, refreshEntitlement } = useApp()
  const nav = useNav()
  const [plan, setPlan] = useState('lifetime')
  const [offer, setOffer] = useState(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let alive = true
    getOfferings().then((o) => alive && setOffer(o))
    return () => {
      alive = false
    }
  }, [])

  const plans = offer?.plans || PLANS.map((p) => ({ ...p, price: null }))

  const buy = async () => {
    setBusy(true)
    try {
      const res = await purchase(plan)
      if (res?.ok) {
        refreshEntitlement()
        toast('أهلًا بك في «جمعيتي بلس»!')
        nav.back()
      } else if (res?.reason !== 'cancel') {
        toast(res?.message || 'لم تكتمل عملية الشراء')
      }
    } finally {
      setBusy(false)
    }
  }

  const doRestore = async () => {
    const res = await restore()
    refreshEntitlement()
    if (res?.ok) toast(res.entitled ? 'تم استرجاع اشتراكك في «بلس»' : 'لا توجد مشتريات على هذا الحساب')
    else toast(res?.message || 'تعذّر استرجاع المشتريات الآن')
  }

  return (
    <Screen
      title=""
      noBack
      className="paywall"
      right={
        <button type="button" className="icon-btn" aria-label="إغلاق" onClick={nav.back}>
          <Icon name="close" />
        </button>
      }
      actions={
        entitled ? (
          <button type="button" className="btn btn-primary btn-block" onClick={nav.back}>
            تم
          </button>
        ) : (
          <div className="pay-actions">
            <button type="button" className="btn btn-gold btn-block" disabled={busy} onClick={buy}>
              <Icon name="crown" size={20} stroke={2.2} /> {plan === 'lifetime' ? 'اشترِ «بلس» مدى الحياة' : 'اشترك في «بلس»'}
            </button>
            <button type="button" className="link" onClick={doRestore}>
              استرجاع المشتريات
            </button>
          </div>
        )
      }
    >
      <div className="pay-hero">
        <img className="pay-logo" src={logo} alt="" />
        <h1 className="pay-title">جمعيتي بلس</h1>
        <p className="pay-sub">{HEAD[reason] || 'كل جمعياتك منظّمة في مكان واحد'}</p>
        {plus && !entitled ? <p className="pay-note">{reviewPlus ? 'كود المراجعة مفعّل: كل المزايا مفتوحة الآن.' : 'وضع التجربة مفعّل: كل المزايا مفتوحة الآن.'}</p> : null}
        {entitled ? <p className="pay-note good">«بلس» مفعّل. شكرًا لدعمك!</p> : null}
      </div>

      <ul className="benefits">
        {BENEFITS.map((b) => (
          <li key={b}>
            <span className="benefit-check">
              <Icon name="check" size={15} stroke={3} />
            </span>
            {b}
          </li>
        ))}
      </ul>

      {!entitled ? (
        <div className="plans" role="radiogroup" aria-label="اختر الخطة">
          {plans.map((p) => (
            <button key={p.id} type="button" role="radio" aria-checked={plan === p.id} className={`plan ${plan === p.id ? 'on' : ''}`} onClick={() => setPlan(p.id)}>
              {p.badge ? <span className="plan-badge">{p.badge}</span> : null}
              <span className="plan-title">{p.title}</span>
              <span className="plan-price">{p.price || '—'}</span>
              <span className="plan-note">{p.note}</span>
            </button>
          ))}
        </div>
      ) : null}

      {!entitled ? (
        <p className="fine-print">
          {offer && !offer.available ? (offer.native ? 'المتجر غير متاح الآن، حاول بعد قليل. ' : 'الشراء متاح في نسخة التطبيق. ') : ''}
          الاشتراك الشهري والسنوي يتجدد تلقائيًا، ويمكنك إلغاؤه في أي وقت من إعدادات المتجر. «مدى الحياة» دفعة واحدة فقط.
        </p>
      ) : null}
      <p className="fine-print">
        {nativePlatform() === 'ios' ? (
          <>
            <a href={TERMS_URL} target="_blank" rel="noreferrer">
              شروط الاستخدام
            </a>
            <span aria-hidden="true"> · </span>
          </>
        ) : null}
        <button type="button" className="link" style={{ fontSize: 12, padding: 0 }} onClick={() => nav.navigate({ name: 'privacy' })}>
          سياسة الخصوصية
        </button>
      </p>
    </Screen>
  )
}
