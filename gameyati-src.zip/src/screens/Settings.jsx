import { useRef, useState } from 'react'
import { useApp } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Confirm, Field, Screen, Sheet, Toggle } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { SHOW_TEST_MODE, APP_VERSION, REVIEW_UNLOCK, SUPPORT_EMAIL } from '../lib/config.js'
import { redeemReviewCode, REVIEW_TAPS } from '../lib/review.js'
import { restore } from '../lib/billing.js'
import { askNotificationPermission, shareFile } from '../lib/native.js'
import { CURRENCIES, todayISO } from '../model/gam.js'

function untilText(ts) {
  try {
    return new Date(ts).toLocaleDateString('ar-EG-u-nu-latn', { day: 'numeric', month: 'long' })
  } catch {
    return ''
  }
}

const HOURS = [8, 9, 10, 12, 14, 17, 19, 21]
const hourLabel = (h) => (h === 12 ? '12 ظهرًا' : h < 12 ? `${h} صباحًا` : `${h - 12} مساءً`)

function toDataUrl(json) {
  const b64 = btoa(unescape(encodeURIComponent(json)))
  return `data:application/json;base64,${b64}`
}

export default function Settings() {
  const { gams, importGams, settings, setSetting, currency, resetAll, toast, plus, entitled, reviewPlus, reviewUntil, setReviewUntil, refreshEntitlement, refreshReminders } =
    useApp()
  const nav = useNav()
  const [askReset, setAskReset] = useState(false)
  const [askCode, setAskCode] = useState(false)
  const [code, setCode] = useState('')
  const [checking, setChecking] = useState(false)
  const [pending, setPending] = useState(null) // نسخة احتياطية مستنية تأكيد
  const fileRef = useRef(null)
  const taps = useRef({ n: 0, t: 0 })

  // ٧ دوسات ورا بعض على «الإصدار» بتفتح خانة كود المراجعة (لمراجعي Google Play)
  const onVersionTap = () => {
    if (!REVIEW_UNLOCK) return
    const now = Date.now()
    const r = taps.current
    r.n = now - r.t < 1500 ? r.n + 1 : 1
    r.t = now
    if (r.n >= REVIEW_TAPS) {
      r.n = 0
      setCode('')
      setAskCode(true)
    }
  }

  const submitCode = async (e) => {
    e.preventDefault()
    if (checking) return
    setChecking(true)
    try {
      const res = await redeemReviewCode(code)
      if (res.ok) {
        setReviewUntil(res.until)
        setAskCode(false)
        toast('تم فتح «بلس» للمراجعة لمدة 7 أيام')
      } else if (res.reason === 'unsupported') toast('هذه الخاصية غير متاحة على هذا الجهاز')
      else toast('الكود غير صحيح')
    } finally {
      setChecking(false)
    }
  }

  const doRestore = async () => {
    const res = await restore()
    refreshEntitlement()
    if (res?.ok) toast(res.entitled ? 'تم استرجاع اشتراكك في «بلس»' : 'لا توجد مشتريات على هذا الحساب')
    else toast(res?.message || 'تعذّر استرجاع المشتريات الآن')
  }

  const toggleReminders = async (on) => {
    setSetting('remindersOn', on)
    if (on) {
      const res = await askNotificationPermission()
      refreshReminders()
      if (res?.ok && res.granted === false) toast('اسمح بالإشعارات من إعدادات الجهاز لتصلك التنبيهات')
    }
  }

  const backup = async () => {
    if (!gams.length) return toast('لا توجد جمعيات لحفظها')
    const json = JSON.stringify({ app: 'gameyati', v: 1, at: new Date().toISOString(), gams })
    const res = await shareFile(toDataUrl(json), `جمعيتي-نسخة-${todayISO()}.json`, 'نسخة احتياطية من جمعيتي')
    if (res?.reason === 'download') toast('تم حفظ الملف')
    else if (!res?.ok && res?.reason !== 'cancel') toast('تعذّر حفظ النسخة، حاول مرة أخرى')
    return undefined
  }

  const onFile = (e) => {
    const f = e.target.files?.[0]
    e.target.value = ''
    if (!f) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const data = JSON.parse(String(reader.result || ''))
        const list = Array.isArray(data) ? data : data?.gams
        if (!Array.isArray(list) || !list.length || (data.app && data.app !== 'gameyati')) throw new Error('bad')
        setPending(list)
      } catch {
        toast('هذا الملف ليس نسخة احتياطية من «جمعيتي»')
      }
    }
    reader.onerror = () => toast('تعذّرت قراءة الملف')
    reader.readAsText(f)
  }

  return (
    <Screen title="الإعدادات">
      <div className="set-group">
        <button type="button" className="plus-card" onClick={() => nav.navigate({ name: 'paywall', reason: 'settings' })}>
          <span className="pay-crown">
            <Icon name="crown" size={24} stroke={2} />
          </span>
          <span style={{ flex: 1 }}>
            <b>{entitled ? '«جمعيتي بلس» مفعّل' : 'جمعيتي بلس'}</b>
            <small>{entitled ? 'شكرًا لدعمك! كل المزايا مفتوحة.' : 'جمعيات بلا حدود، تقارير PDF، بدون إعلانات'}</small>
          </span>
          <Icon name="chev" size={18} />
        </button>
        {reviewPlus && !entitled ? <p className="field-hint" style={{ margin: '8px 4px 0' }}>كود المراجعة مفعّل حتى {untilText(reviewUntil)}.</p> : null}
      </div>

      {SHOW_TEST_MODE ? (
        <div className="set-group">
          <Toggle label="وضع التجربة: فتح «بلس»" sub="للمعاينة فقط — غير موجود في نسخة المتجر" checked={settings.testPlus} onChange={(v) => setSetting('testPlus', v)} />
        </div>
      ) : null}

      <div className="section-label">
        <span>التنبيهات</span>
      </div>
      <div className="set-group">
        <Toggle label="تذكير بمواعيد الدفع والقبض" sub="تنبيه على الجهاز في يوم كل دور" checked={settings.remindersOn !== false} onChange={toggleReminders} />
        {settings.remindersOn !== false ? (
          <Field label="وقت التنبيه" className="tight">
            <select value={settings.remindHour || 10} onChange={(e) => setSetting('remindHour', Number(e.target.value))} aria-label="وقت التنبيه">
              {HOURS.map((h) => (
                <option key={h} value={h}>
                  {hourLabel(h)}
                </option>
              ))}
            </select>
          </Field>
        ) : null}
      </div>

      <div className="section-label">
        <span>العملة الافتراضية</span>
      </div>
      <div className="set-group">
        <Field className="tight">
          <select value={currency} onChange={(e) => setSetting('currency', e.target.value)} aria-label="العملة الافتراضية">
            {CURRENCIES.map((c) => (
              <option key={c.code} value={c.code}>
                {c.label} ({c.short})
              </option>
            ))}
          </select>
        </Field>
      </div>

      <div className="section-label">
        <span>النسخ الاحتياطي</span>
      </div>
      <p className="field-hint" style={{ margin: '-4px 4px 10px' }}>
        بياناتك على هذا الجهاز فقط. احفظ نسخة على Drive أو أرسلها لنفسك على واتساب، لتسترجعها لو غيّرت جهازك.
      </p>
      <div className="set-group menu-list">
        <button type="button" className="menu-item" onClick={backup}>
          <Icon name="download" /> حفظ نسخة احتياطية
        </button>
        <button type="button" className="menu-item" onClick={() => fileRef.current?.click()}>
          <Icon name="upload" /> استرجاع نسخة احتياطية
        </button>
      </div>
      <input ref={fileRef} type="file" accept=".json,application/json,text/plain,*/*" style={{ display: 'none' }} onChange={onFile} />

      <div className="set-group menu-list">
        <button type="button" className="menu-item" onClick={doRestore}>
          <Icon name="refresh" /> استرجاع المشتريات
        </button>
        <a className="menu-item" href={`mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent('جمعيتي — ملاحظة')}`} style={{ color: 'inherit', textDecoration: 'none' }}>
          <Icon name="mail" /> راسلنا (اقتراح أو مشكلة)
        </a>
        <button type="button" className="menu-item" onClick={() => nav.navigate({ name: 'privacy' })}>
          <Icon name="shield" /> سياسة الخصوصية
        </button>
        <button type="button" className="menu-item danger" onClick={() => setAskReset(true)}>
          <Icon name="trash" /> حذف كل البيانات من الجهاز
        </button>
      </div>

      <button type="button" className="version" onClick={onVersionTap}>
        الإصدار {APP_VERSION}
        {plus ? ' · بلس' : ''}
      </button>

      <Confirm
        open={!!pending}
        title="استرجاع النسخة الاحتياطية؟"
        text={pending ? `الملف فيه ${pending.length} جمعية. سيتم دمجها مع جمعياتك الحالية (الجمعية الموجودة تُستبدل بالنسخة الأحدث).` : ''}
        yes="استرجاع"
        onYes={() => {
          const r = importGams(pending)
          setPending(null)
          toast(`تم الاسترجاع: ${r.added} جديدة، ${r.updated} محدّثة`)
        }}
        onNo={() => setPending(null)}
      />
      <Confirm
        open={askReset}
        title="حذف كل البيانات؟"
        text="سيتم حذف كل الجمعيات المحفوظة على هذا الجهاز نهائيًا. اشتراكك في «بلس» لن يتأثر."
        yes="حذف الكل"
        danger
        onYes={() => {
          resetAll()
          setAskReset(false)
          toast('تم حذف كل البيانات')
        }}
        onNo={() => setAskReset(false)}
      />

      <Sheet open={askCode} title="كود المراجعة" onClose={() => setAskCode(false)}>
        <form onSubmit={submitCode}>
          <p className="confirm-text" style={{ marginBottom: 12 }}>
            اكتب الكود لفتح «بلس».
            <span lang="en" dir="ltr" style={{ display: 'block' }}>
              Enter your review code to unlock Gameyati Plus.
            </span>
          </p>
          <div className="field">
            <input
              dir="ltr"
              lang="en"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="Review code"
              aria-label="كود المراجعة"
              autoComplete="off"
              autoCapitalize="characters"
              autoCorrect="off"
              spellCheck={false}
              maxLength={40}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-block" disabled={checking || !code.trim()}>
            تفعيل
          </button>
        </form>
      </Sheet>
    </Screen>
  )
}
