import { useEffect, useState } from 'react'
import { useApp, useGam } from '../state/app.jsx'
import { useNav } from '../state/nav.jsx'
import { Screen, Toggle } from '../components/ui.jsx'
import { Icon } from '../components/Icons.jsx'
import { displayName } from '../model/gam.js'
import { renderSchedule } from '../lib/scheduleImage.js'
import { shareFile, shareText } from '../lib/native.js'
import { scheduleText } from '../lib/messages.js'
import { maybeAd } from '../lib/ads.js'

export default function Share({ id }) {
  const [g] = useGam(id)
  const { plus, settings, setSetting, toast } = useApp()
  const nav = useNav()
  const [img, setImg] = useState('')
  const [busy, setBusy] = useState(false)
  const brand = !(plus && settings.noBrand)

  useEffect(() => {
    let alive = true
    if (!g) return undefined
    setImg('')
    renderSchedule(g, { brand }).then((url) => alive && setImg(url))
    return () => {
      alive = false
    }
  }, [g, brand])

  if (!g) return null
  const name = `جدول ${displayName(g)}.png`.replace(/[\\/:*?"<>|]+/g, ' ')

  const share = async () => {
    if (!img || busy) return
    setBusy(true)
    try {
      const res = await shareFile(img, name, `جدول ${displayName(g)}`)
      if (res?.reason === 'download') toast('تم حفظ الصورة')
      else if (!res?.ok && res?.reason !== 'cancel') toast('تعذّرت المشاركة، حاول مرة أخرى')
    } finally {
      setBusy(false)
    }
    setTimeout(() => maybeAd(plus), 900)
  }

  const shareTxt = async () => {
    const res = await shareText(scheduleText(g, brand), displayName(g))
    if (res?.reason === 'copied') toast('تم نسخ الجدول')
    setTimeout(() => maybeAd(plus), 900)
  }

  return (
    <Screen
      title="مشاركة الجدول"
      sub={displayName(g)}
      actions={
        <div className="dock">
          <button type="button" className="btn btn-primary" style={{ flex: 1 }} disabled={!img || busy} onClick={share}>
            <Icon name="share" size={20} /> مشاركة الصورة
          </button>
          <button type="button" className="btn btn-ghost" onClick={shareTxt}>
            <Icon name="list" size={20} /> كنص
          </button>
        </div>
      }
    >
      <div className="share-preview">{img ? <img src={img} alt={`جدول ${displayName(g)}`} /> : <div className="share-loading">جارٍ تجهيز الصورة…</div>}</div>
      <div style={{ marginTop: 14 }}>
        <Toggle
          label="بدون علامة «جمعيتي»"
          sub={plus ? 'إخفاء اسم التطبيق من أسفل الصورة' : 'متاح في «بلس»'}
          checked={plus && !!settings.noBrand}
          onChange={(v) => (plus ? setSetting('noBrand', v) : nav.navigate({ name: 'paywall', reason: 'brand' }))}
        />
      </div>
    </Screen>
  )
}
