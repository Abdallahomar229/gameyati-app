// حالة التطبيق: الجمعيات (محفوظة على الموبايل بس) + الإعدادات + «بلس» + الرسائل السريعة
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { load, save, clearAll } from '../lib/storage.js'
import * as billing from '../lib/billing.js'
import { loadReviewUntil, keepReview } from '../lib/review.js'
import { SHOW_TEST_MODE } from '../lib/config.js'
import { normalize, syncTurns, uid } from '../model/gam.js'
import { syncReminders } from '../lib/reminders.js'
import { askNotificationPermission } from '../lib/native.js'

// المجاني: جمعية واحدة بنظّمها (الجمعيات اللي أنا مشترك فيها مفتوحة)
export const FREE_ORG_LIMIT = 1

const DEFAULT_SETTINGS = { testPlus: false, remindersOn: true, remindHour: 10, currency: '', noBrand: false }
const AppCtx = createContext(null)

function loadGams() {
  const list = load('gams', [])
  return Array.isArray(list) ? list.map(normalize).filter(Boolean) : []
}

export function guessCurrency() {
  try {
    const langs = [...(navigator.languages || []), navigator.language || '']
    const map = { EG: 'EGP', SA: 'SAR', AE: 'AED', KW: 'KWD', QA: 'QAR', BH: 'BHD', OM: 'OMR', JO: 'JOD', IQ: 'IQD', LY: 'LYD', TN: 'TND', DZ: 'DZD', MA: 'MAD', SD: 'SDG' }
    for (const l of langs) {
      const r = /-([A-Z]{2})\b/i.exec(l)?.[1]?.toUpperCase()
      if (r && map[r]) return map[r]
    }
  } catch {
    /* تجاهل */
  }
  return 'EGP'
}

export function AppProvider({ children }) {
  const [gams, setGams] = useState(loadGams)
  const [settings, setSettings] = useState(() => ({ ...DEFAULT_SETTINGS, ...load('settings', {}) }))
  const [entitled, setEntitled] = useState(() => billing.isPlus())
  const [reviewUntil, setReviewUntil] = useState(loadReviewUntil)
  const [toastState, setToastState] = useState(null)
  const saveTimer = useRef(null)
  const latest = useRef(gams)
  latest.current = gams

  // الحفظ بعد ما التعديلات تهدى شوية (ومع الخروج من التطبيق فورًا)
  useEffect(() => {
    clearTimeout(saveTimer.current)
    saveTimer.current = setTimeout(() => {
      if (!save('gams', gams)) setToastState({ msg: 'مساحة التخزين ممتلئة — احذف جمعية قديمة', id: Date.now() })
    }, 250)
  }, [gams])
  useEffect(() => {
    const flush = () => save('gams', latest.current)
    const onVis = () => document.visibilityState === 'hidden' && flush()
    window.addEventListener('pagehide', flush)
    document.addEventListener('visibilitychange', onVis)
    return () => {
      window.removeEventListener('pagehide', flush)
      document.removeEventListener('visibilitychange', onVis)
    }
  }, [])

  useEffect(() => {
    save('settings', settings)
  }, [settings])

  // التنبيهات بتتحدّث مع أي تعديل
  const [notifTick, setNotifTick] = useState(0)
  useEffect(() => {
    syncReminders(gams, settings)
  }, [gams, settings, notifTick])

  // إذن التنبيهات: بنطلبه مرة واحدة بعد أول جمعية (مش أول ما التطبيق يفتح)
  useEffect(() => {
    if (!gams.length || settings.remindersOn === false || load('askedNotif', false)) return
    save('askedNotif', true)
    askNotificationPermission().then(() => setNotifTick((n) => n + 1))
  }, [gams.length, settings.remindersOn])

  useEffect(() => {
    if (!toastState) return undefined
    const t = setTimeout(() => setToastState(null), 2800)
    return () => clearTimeout(t)
  }, [toastState])

  useEffect(() => {
    const onEnt = () => setEntitled(billing.isPlus())
    window.addEventListener('gameyati:entitlement', onEnt)
    return () => window.removeEventListener('gameyati:entitlement', onEnt)
  }, [])

  const toast = useCallback((msg) => setToastState({ msg, id: Date.now() }), [])
  const refreshReminders = useCallback(() => setNotifTick((n) => n + 1), [])
  const setSetting = useCallback((key, value) => setSettings((s) => ({ ...s, [key]: value })), [])
  const refreshEntitlement = useCallback(() => setEntitled(billing.isPlus()), [])

  const addGam = useCallback((g) => {
    const item = normalize({ ...g, createdAt: Date.now(), updatedAt: Date.now() })
    setGams((list) => [item, ...list.filter((x) => x.id !== item.id)])
    return item.id
  }, [])

  // patch: كائن بالحقول الجديدة أو دالة (g) => g
  const updateGam = useCallback((id, patch) => {
    setGams((list) =>
      list.map((g) => {
        if (g.id !== id) return g
        let next = typeof patch === 'function' ? patch(g) : { ...g, ...patch }
        if (next.kind === 'org') next = syncTurns(next)
        return { ...next, updatedAt: Date.now() }
      }),
    )
  }, [])

  const deleteGam = useCallback((id) => setGams((list) => list.filter((g) => g.id !== id)), [])

  const duplicateGam = useCallback((id) => {
    const src = latest.current.find((g) => g.id === id)
    if (!src) return null
    const copy = normalize({
      ...JSON.parse(JSON.stringify(src)),
      id: uid('g'),
      name: `${src.name || 'جمعية'} (جديدة)`,
      payments: {},
      paidOut: {},
      paid: {},
      received: 0,
      archived: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    })
    setGams((list) => [copy, ...list])
    return copy.id
  }, [])

  // استرجاع نسخة احتياطية: بندمج بالـid (النسخة الأحدث تكسب)
  const importGams = useCallback((items) => {
    const incoming = (Array.isArray(items) ? items : []).map(normalize).filter(Boolean)
    let added = 0
    let updated = 0
    setGams((list) => {
      const byId = new Map(list.map((g) => [g.id, g]))
      for (const g of incoming) {
        const cur = byId.get(g.id)
        if (!cur) {
          byId.set(g.id, g)
          added++
        } else if ((g.updatedAt || 0) >= (cur.updatedAt || 0)) {
          byId.set(g.id, g)
          updated++
        }
      }
      return [...byId.values()].sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))
    })
    return { added, updated, total: incoming.length }
  }, [])

  const resetAll = useCallback(() => {
    const had = billing.isPlus()
    const review = loadReviewUntil()
    clearAll()
    billing.keepEntitlement(had)
    keepReview(review)
    setGams([])
    setSettings({ ...DEFAULT_SETTINGS })
    setEntitled(had)
  }, [])

  const reviewPlus = reviewUntil > Date.now()
  const plus = entitled || reviewPlus || (SHOW_TEST_MODE && !!settings.testPlus)
  const currency = settings.currency || guessCurrency()
  const orgCount = gams.filter((g) => g.kind === 'org' && !g.archived).length
  const canAddOrg = plus || orgCount < FREE_ORG_LIMIT

  const value = useMemo(
    () => ({
      gams,
      addGam,
      updateGam,
      deleteGam,
      duplicateGam,
      importGams,
      settings,
      setSetting,
      currency,
      plus,
      entitled,
      refreshEntitlement,
      reviewPlus,
      reviewUntil,
      setReviewUntil,
      canAddOrg,
      toast,
      toastState,
      resetAll,
      refreshReminders,
    }),
    [gams, addGam, updateGam, deleteGam, duplicateGam, importGams, settings, setSetting, currency, plus, entitled, refreshEntitlement, reviewPlus, reviewUntil, canAddOrg, toast, toastState, resetAll, refreshReminders],
  )
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>
}

export function useApp() {
  return useContext(AppCtx)
}

export function useGam(id) {
  const { gams, updateGam } = useApp()
  const g = gams.find((x) => x.id === id) || null
  const update = useCallback((patch) => updateGam(id, patch), [id, updateGam])
  return [g, update]
}
